import { useCallback, useEffect, useRef, useState } from "react";
import * as Y from "yjs";
import { IndexeddbPersistence } from "y-indexeddb";
import { io } from "socket.io-client";
import { util as fabricUtil } from "fabric";
import {
  Canvas,
  ActiveSelection,
  FabricImage,
  IText,
  PencilBrush,
  Point,
  Rect,
  Ellipse,
  Triangle,
  Line,
  Polygon,
  Path,
  Group,
  Textbox,
} from "fabric";
import { STICKY_TEMPLATES, createStickyNote } from "./stickyNoteTemplates";
import { clampZoom, getWorldPointer, getZoomLevel } from "./canvasCoordinates";
import "./App.css";

const W = 1000;
const H = 680;
const BG = "#F8FAFC";
const FONTS = ["Arial", "Georgia", "Verdana", "Trebuchet MS", "Courier New", "Times New Roman"];
const EXTRA_PROPS = [
  "stickyNoteData", "stickyPart", "isPixelForgeText", "isPixelForgeStroke",
  "pixelForgeObjectType", "brushKind", "brushColor", "brushWidth",
  "brushOpacity", "pressureEnabled", "imageName", "imageMimeType", "isPixelForgeLocked", "pixelForgeGroupId",
   "createdById", "lockedById", "isPixelForgeGroup", "isPixelForgeLassoPreview", "pixelForgeSyncId",
];
function colorWithAlpha(color, alpha) {
  const hex = String(color || "#FDE047").replace("#", "");
  const normalized = hex.length === 3
    ? hex.split("").map((char) => char + char).join("")
    : hex;
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) {
    return `rgba(253, 224, 71, ${alpha})`;
  }
  const red = parseInt(normalized.slice(0, 2), 16);
  const green = parseInt(normalized.slice(2, 4), 16);
  const blue = parseInt(normalized.slice(4, 6), 16);
  return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}


class PressurePencilBrush extends PencilBrush {
  constructor(canvas, kind, settings) {
    super(canvas);
    this.kind = kind;
    this.settings = settings;
    this.baseWidth = settings.width;
    this.color = settings.color;
    this.width = settings.width;
    this.strokeLineCap = kind === "calligraphy" ? "square" : "round";
    this.strokeLineJoin = "round";
    this.strokeDashArray = kind === "pencil" ? [1, 1.8] : null;
  }

  _pressureWidth(event) {
    const s = this.settings;
    const p = event && typeof event.pressure === "number" && event.pressure > 0
      ? event.pressure
      : 0.5;
    if (!s.pressureEnabled || !event || typeof event.pressure !== "number" || event.pressure <= 0) {
      return s.width;
    }
    return Math.max(1, s.width * (0.35 + p * 1.3));
  }

  onMouseDown(pointer, event) {
    this.settings.width = this.settings.width || 4;
    this.width = this._pressureWidth(event);
    this.color = this.settings.color;
    this.opacity = this.settings.opacity;
    this.strokeDashArray = this.kind === "pencil" ? [1, 1.8] : null;
    super.onMouseDown(pointer, event);
  }

  onMouseMove(pointer, event) {
    this.width = this._pressureWidth(event);
    this.color = this.settings.color;
    super.onMouseMove(pointer, event);
  }

_setBrushStyles(ctx) {
  super._setBrushStyles(ctx);

  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  if (this.kind === "highlighter") {
    ctx.globalAlpha = 0.30;
  } else {
    ctx.globalAlpha = this.settings.opacity;
  }
}
}

function makeBrush(canvas, kind, settings) {
  const brush = new PressurePencilBrush(canvas, kind, settings);
  brush.width = settings.width;
  brush.color = settings.color;
  return brush;
}


const SHAPE_CATEGORIES = [
  { label: "Basic shapes", options: [["rectangle","Rectangle"],["roundedRect","Rounded rectangle"],["square","Square"],["circle","Circle"],["ellipse","Ellipse"],["triangle","Triangle"],["diamond","Diamond"]] },
  { label: "Polygons", options: [["pentagon","Pentagon"],["hexagon","Hexagon"],["heptagon","Heptagon"],["octagon","Octagon"],["nonagon","Nonagon"],["decagon","Decagon"],["parallelogram","Parallelogram"],["trapezoid","Trapezoid"]] },
  { label: "Stars & bursts", options: [["star4","4-point star"],["star5","5-point star"],["star6","6-point star"],["star8","8-point star"],["burst","Burst"],["sun","Sunburst"],["gear","Gear"]] },
  { label: "Arrows", options: [["arrowUp","Up arrow"],["arrowDown","Down arrow"],["arrowLeft","Left arrow"],["arrowRight","Right arrow"],["doubleArrow","Double arrow"],["chevron","Chevron"]] },
  { label: "Banners & symbols", options: [["heart","Heart"],["lightning","Lightning"],["cross","Cross"],["plus","Plus"],["moon","Crescent moon"],["smiley","Smiley"],["cloud","Cloud"],["speech","Speech bubble"],["thought","Thought bubble"],["callout","Callout"]] },
];

function polygonPoints(sides, width=100, height=100, inset=0.08) {
  const points = [];
  for (let i=0;i<sides;i++) {
    const a = -Math.PI/2 + i * Math.PI*2/sides;
    points.push({ x: width/2 + Math.cos(a)*width*(0.5-inset), y: height/2 + Math.sin(a)*height*(0.5-inset) });
  }
  return points;
}
function pathForShape(kind) {
  const paths = {
    diamond: "M 50 0 L 100 50 L 50 100 L 0 50 Z",
    parallelogram: "M 25 0 L 100 0 L 75 100 L 0 100 Z",
    trapezoid: "M 25 0 L 75 0 L 100 100 L 0 100 Z",
    star4: "M 50 0 L 61 37 L 100 50 L 61 63 L 50 100 L 39 63 L 0 50 L 39 37 Z",
    star5: "M 50 0 L 61 35 L 98 36 L 69 59 L 79 96 L 50 74 L 21 96 L 31 59 L 2 36 L 39 35 Z",
    star6: "M 50 0 L 64 25 L 93 25 L 78 50 L 93 75 L 64 75 L 50 100 L 36 75 L 7 75 L 22 50 L 7 25 L 36 25 Z",
    star8: "M 38 0 L 62 0 L 62 30 L 85 15 L 100 35 L 75 50 L 100 65 L 85 85 L 62 70 L 62 100 L 38 100 L 38 70 L 15 85 L 0 65 L 25 50 L 0 35 L 15 15 L 38 30 Z",
    burst: "M 50 0 L 59 27 L 80 8 L 76 36 L 100 31 L 82 50 L 100 69 L 76 64 L 80 92 L 59 73 L 50 100 L 41 73 L 20 92 L 24 64 L 0 69 L 18 50 L 0 31 L 24 36 L 20 8 L 41 27 Z",
    sun: "M 50 0 L 58 24 L 76 7 L 76 32 L 100 25 L 87 46 L 100 58 L 75 62 L 87 86 L 62 77 L 50 100 L 40 76 L 20 93 L 24 67 L 0 70 L 15 50 L 0 31 L 26 34 L 20 8 L 42 25 Z",
    arrowUp: "M 50 0 L 100 55 L 68 55 L 68 100 L 32 100 L 32 55 L 0 55 Z",
    arrowDown: "M 32 0 L 68 0 L 68 45 L 100 45 L 50 100 L 0 45 L 32 45 Z",
    arrowRight: "M 0 32 L 45 32 L 45 0 L 100 50 L 45 100 L 45 68 L 0 68 Z",
    arrowLeft: "M 100 32 L 55 32 L 55 0 L 0 50 L 55 100 L 55 68 L 100 68 Z",
    doubleArrow: "M 0 50 L 25 20 L 25 38 L 75 38 L 75 20 L 100 50 L 75 80 L 75 62 L 25 62 L 25 80 Z",
    chevron: "M 0 0 L 55 0 L 100 50 L 55 100 L 0 100 L 45 50 Z",
    heart: "M 50 92 C 40 80 0 55 0 28 C 0 0 35 -5 50 20 C 65 -5 100 0 100 28 C 100 55 60 80 50 92 Z",
    lightning: "M 58 0 L 18 55 L 45 55 L 35 100 L 83 38 L 55 38 Z",
    cross: "M 35 0 L 65 0 L 65 35 L 100 35 L 100 65 L 65 65 L 65 100 L 35 100 L 35 65 L 0 65 L 0 35 L 35 35 Z",
    plus: "M 40 0 L 60 0 L 60 40 L 100 40 L 100 60 L 60 60 L 60 100 L 40 100 L 40 60 L 0 60 L 0 40 L 40 40 Z",
    moon: "M 75 5 C 20 0 0 35 10 65 C 25 105 75 100 95 65 C 60 78 40 45 75 5 Z",
    cloud: "M 20 70 C -5 65 0 35 22 35 C 25 5 60 5 68 28 C 95 20 110 55 85 68 Z",
    speech: "M 8 12 Q 8 0 25 0 L 75 0 Q 95 0 95 18 L 95 55 Q 95 70 75 70 L 40 70 L 20 95 L 25 70 Q 8 68 8 52 Z",
    thought: "M 20 20 C 20 0 55 0 58 18 C 82 0 105 20 90 38 C 110 60 80 78 65 65 C 45 85 20 68 28 53 C 5 50 5 30 20 20 Z",
    callout: "M 5 5 L 95 5 L 95 70 L 45 70 L 25 95 L 28 70 L 5 70 Z",
    smiley: "M 50 2 A 48 48 0 1 1 49.9 2 Z M 30 35 L 30 36 M 68 35 L 68 36 M 28 58 Q 50 82 72 58",
    gear: "M 50 0 L 60 12 L 76 7 L 80 23 L 96 30 L 88 44 L 100 55 L 84 65 L 86 82 L 68 82 L 58 100 L 45 87 L 30 95 L 25 78 L 8 72 L 16 57 L 0 45 L 15 34 L 12 18 L 31 20 L 40 3 Z",
  };
  if (paths[kind]) return paths[kind];
  const polygonMap = { pentagon:5, hexagon:6, heptagon:7, octagon:8, nonagon:9, decagon:10 };
  if (polygonMap[kind]) return polygonPoints(polygonMap[kind],100,100,0).map((p,i)=>`${i?'L':'M'} ${p.x} ${p.y}`).join(' ')+' Z';
  if (kind === 'circle' || kind === 'ellipse') return null;
  return null;
}

function wavyPathFromPoints(points) {
  if (points.length < 2) return "";
  if (points.length > 2) return curvePathFromPoints(points);
  const [a,b] = points;
  const dx=b.x-a.x, dy=b.y-a.y, length=Math.hypot(dx,dy)||1;
  const nx=-dy/length, ny=dx/length;
  const steps=24, amplitude=Math.min(24,length/8);
  const out=[];
  for(let i=0;i<=steps;i++) {
    const t=i/steps, wave=Math.sin(t*Math.PI*4)*amplitude;
    out.push({x:a.x+dx*t+nx*wave,y:a.y+dy*t+ny*wave});
  }
  return out.map((p,i)=>`${i?'L':'M'} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`).join(' ');
}

function curvePathFromPoints(points) {
  if (points.length < 2) return "";
  const p = (point) => `${point.x.toFixed(2)} ${point.y.toFixed(2)}`;
  let d = `M ${p(points[0])}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[Math.max(0, i - 1)];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[Math.min(points.length - 1, i + 2)];
    const c1 = { x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6 };
    const c2 = { x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6 };
    d += ` C ${p(c1)} ${p(c2)} ${p(p2)}`;
  }
  return d;
}

export default function App() {
  const canvasElement = useRef(null);
  const canvasRef = useRef(null);
  const imageInputRef = useRef(null);
  const canvasImportRef = useRef(null);
  const shapeDrawRef = useRef({ active: false, start: null, preview: null });
  const curvePointsRef = useRef([]);
  const curvePreviewRef = useRef(null);
  const lassoRef = useRef({ active: false, points: [], preview: null });
  const currentUserIdRef = useRef("user-1");
  const collaborationRef = useRef({ doc: null, objects: null, socket: null, applyingRemote: false, cursors: null });
  const [roomId, setRoomId] = useState("pixelforge-demo");
  const [serverUrl, setServerUrl] = useState("http://localhost:3001");
  const [collabStatus, setCollabStatus] = useState("Offline");
  const [remoteCursors, setRemoteCursors] = useState([]);
  const [localCursor, setLocalCursor] = useState({ x: 0, y: 0 });
  const [revisions, setRevisions] = useState([]);
  const [selectedRevisionId, setSelectedRevisionId] = useState("");
  const [revisionCompare, setRevisionCompare] = useState(null);
  const [latencyMs, setLatencyMs] = useState(null);
  const [lastPingAt, setLastPingAt] = useState(0);
  const minimapElement = useRef(null);
  const [gridVisible, setGridVisible] = useState(true);
  const [snapEnabled, setSnapEnabled] = useState(false);
  const [minimapVisible, setMinimapVisible] = useState(true);
  const gridVisibleRef = useRef(true);
  const snapEnabledRef = useRef(false);
  const minimapVisibleRef = useRef(true);
  const modeRef = useRef("select");
  const brushSettingsRef = useRef({
    kind: "pen", color: "#252525", width: 4, opacity: 1, pressureEnabled: true,
  });
  const textSettingsRef = useRef({
    fontFamily: "Arial", fontSize: 24, textColor: "#252525", bold: false,
    italic: false, underline: false, textAlign: "left",
    textBackground: "transparent", lineSpacing: 1.2,
  });
  const historyRef = useRef({ undo: [], redo: [], restoring: false });
  const historyTimer = useRef(null);
  const eraserRef = useRef({ active: false, lastPoint: null });
  const panRef = useRef({ active: false, lastX: 0, lastY: 0 });
  // Coalesce rapid pointer events into one viewport update per animation frame.
  const panFrameRef = useRef(null);
  const pendingPanRef = useRef({ dx: 0, dy: 0 });
  const spaceDownRef = useRef(false);
  const [zoomPercent, setZoomPercent] = useState(100);

  const [mode, setMode] = useState("select");
  // Demo identity controls make creator/admin permissions testable in this local prototype.
  const [currentUserId, setCurrentUserId] = useState("user-1");
  const [adminOverride, setAdminOverride] = useState(false);
  const [shapeTool, setShapeTool] = useState("rectangle");
  const [lineTool, setLineTool] = useState("smooth");
  const [tableRows, setTableRows] = useState(4);
  const [tableCols, setTableCols] = useState(3);
  const [graphType, setGraphType] = useState("bar");
  const [graphData, setGraphData] = useState("Label,Value\nA,12\nB,19\nC,8\nD,15");
  const shapeToolRef = useRef("rectangle");
  const lineToolRef = useRef("smooth");
  const [selectedObject, setSelectedObject] = useState(null);
  const [floatingToolbarPosition, setFloatingToolbarPosition] = useState(null);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [status, setStatus] = useState("Choose a tool to begin.");

  const [brushKind, setBrushKind] = useState("pen");
  const [brushColor, setBrushColor] = useState("#252525");
  const [brushWidth, setBrushWidth] = useState(4);
  const [brushOpacity, setBrushOpacity] = useState(1);
  const [pressureEnabled, setPressureEnabled] = useState(true);
  const [eraserMode, setEraserMode] = useState("sweep");
  const [eraserWidth, setEraserWidth] = useState(22);
  const [highlighterColor, setHighlighterColor] = useState("#FDE047");

  // Existing sticky-note designer state.
  const [template, setTemplate] = useState("sunny");
  const [header, setHeader] = useState("Title");
  const [body, setBody] = useState("Write something...");
  const [headerFont, setHeaderFont] = useState("Georgia");
  const [bodyFont, setBodyFont] = useState("Arial");
  const [headerSize, setHeaderSize] = useState(25);
  const [bodySize, setBodySize] = useState(17);
  const [headerColor, setHeaderColor] = useState("");
  const [bodyColor, setBodyColor] = useState("");
  const [noteWidth, setNoteWidth] = useState(280);
  const [noteHeight, setNoteHeight] = useState(200);
  const [busy, setBusy] = useState(false);

  // Standalone text formatting state.
  const [fontFamily, setFontFamily] = useState("Arial");
  const [fontSize, setFontSize] = useState(24);
  const [textColor, setTextColor] = useState("#252525");
  const [bold, setBold] = useState(false);
  const [italic, setItalic] = useState(false);
  const [underline, setUnderline] = useState(false);
  const [textAlign, setTextAlign] = useState("left");
  const [textBackground, setTextBackground] = useState("transparent");
  const [lineSpacing, setLineSpacing] = useState(1.2);

  const selectedTemplate = STICKY_TEMPLATES[template];

  const syncHistoryButtons = useCallback(() => {
    setCanUndo(historyRef.current.undo.length > 1);
    setCanRedo(historyRef.current.redo.length > 0);
  }, []);

  const saveHistory = useCallback(() => {
    const canvas = canvasRef.current;
    const hist = historyRef.current;
    if (!canvas || hist.restoring) return;
    window.clearTimeout(historyTimer.current);
    historyTimer.current = window.setTimeout(() => {
      const c = canvasRef.current;
      if (!c || hist.restoring) return;
      const json = JSON.stringify(c.toJSON(EXTRA_PROPS));
      if (hist.undo[hist.undo.length - 1] !== json) {
        hist.undo.push(json);
        if (hist.undo.length > 80) hist.undo.shift();
        hist.redo = [];
        syncHistoryButtons();
      }
    }, 100);
  }, [syncHistoryButtons]);

  const updateFloatingToolbar = useCallback((obj) => {
    const canvas = canvasRef.current;
    if (!canvas || !obj || modeRef.current !== "select" || obj.isEditing) {
      setFloatingToolbarPosition(null);
      return;
    }
    const bounds = obj.getBoundingRect();
    const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
    const zoom = canvas.getZoom() || 1;
    // Fabric's bounding rectangle is in scene/world coordinates. Convert it
    // through the viewport transform to position the HTML toolbar on screen.
    const left = bounds.left * zoom + vpt[4];
    const top = bounds.top * zoom + vpt[5];
    const frame = canvas.wrapperEl?.parentElement;
    const frameRect = frame?.getBoundingClientRect();
    const canvasRect = canvas.upperCanvasEl?.getBoundingClientRect();
    if (!frameRect || !canvasRect) return;
    const scaleX = canvasRect.width / (canvas.getWidth() || 1);
    const scaleY = canvasRect.height / (canvas.getHeight() || 1);
    const localLeft = (left * scaleX) + (canvasRect.left - frameRect.left);
    const localTop = (top * scaleY) + (canvasRect.top - frameRect.top);
    const toolbarWidth = 430;
    const x = Math.max(8, Math.min(localLeft + bounds.width * zoom * scaleX / 2 - toolbarWidth / 2, frameRect.width - toolbarWidth - 8));
    const y = Math.max(8, localTop - 48);
    setFloatingToolbarPosition({ left: x, top: y });
  }, []);

  const updateSelected = useCallback((obj) => {
    setSelectedObject(obj || null);
    updateFloatingToolbar(obj || null);
    if (!obj || !obj.isPixelForgeText) return;
    setFontFamily(obj.fontFamily || "Arial");
    setFontSize(obj.fontSize || 24);
    setTextColor(typeof obj.fill === "string" ? obj.fill : "#252525");
    setBold(obj.fontWeight === "bold");
    setItalic(obj.fontStyle === "italic");
    setUnderline(Boolean(obj.underline));
    setTextAlign(obj.textAlign || "left");
    setTextBackground(obj.backgroundColor || "transparent");
    setLineSpacing(Number(obj.lineHeight) || 1.2);
  }, [updateFloatingToolbar]);

  const installBrush = useCallback((canvas, kind, settings) => {
    const actualKind = kind === "highlighter" ? "highlighter" : kind;
    const adjusted = {
      ...settings,
      color: actualKind === "highlighter" ? settings.color : settings.color,
      opacity: actualKind === "highlighter" ? Math.min(settings.opacity, 0.32) : settings.opacity,
      width: actualKind === "highlighter" ? Math.max(settings.width, 18) : settings.width,
    };
    const brush = makeBrush(canvas, actualKind, adjusted);
    if (actualKind === "highlighter") {
      // PencilBrush uses the color as the stroke; alpha is set in _setBrushStyles.
      brush.width = Math.max(settings.width, 18);
    }
    canvas.freeDrawingBrush = brush;
  }, []);

  const drawGrid = useCallback((canvas) => {
    if (!canvas || !gridVisibleRef.current) return;
    const ctx = canvas.getContext();
    const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
    const zoom = Math.max(0.01, vpt[0] || 1);
    const step = 25;
    const width = canvas.getWidth();
    const height = canvas.getHeight();
    const worldLeft = -vpt[4] / zoom;
    const worldTop = -vpt[5] / zoom;
    const startX = ((worldLeft % step) + step) % step;
    const startY = ((worldTop % step) + step) % step;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.strokeStyle = "rgba(112, 125, 151, 0.16)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = (step - startX) * zoom; x < width; x += step * zoom) {
      const crispX = Math.round(x) + 0.5;
      ctx.moveTo(crispX, 0); ctx.lineTo(crispX, height);
    }
    for (let y = (step - startY) * zoom; y < height; y += step * zoom) {
      const crispY = Math.round(y) + 0.5;
      ctx.moveTo(0, crispY); ctx.lineTo(width, crispY);
    }
    ctx.stroke();
    ctx.restore();
  }, []);

  const drawMinimap = useCallback(() => {
    const canvas = canvasRef.current;
    const mini = minimapElement.current;
    if (!canvas || !mini || !minimapVisibleRef.current) return;
    const ctx = mini.getContext("2d");
    const w = mini.width, h = mini.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#f8fafc"; ctx.fillRect(0, 0, w, h);
    const objects = canvas.getObjects().filter((o) => !o.isGridHelper);
    const bounds = objects.map((o) => o.getBoundingRect()).filter((b) => Number.isFinite(b.left) && Number.isFinite(b.top));
    const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
    const zoom = Math.max(0.01, vpt[0] || 1);
    const view = { left: -vpt[4] / zoom, top: -vpt[5] / zoom, width: canvas.getWidth() / zoom, height: canvas.getHeight() / zoom };
    let minX = Math.min(view.left, ...bounds.map((b) => b.left), -100);
    let minY = Math.min(view.top, ...bounds.map((b) => b.top), -100);
    let maxX = Math.max(view.left + view.width, ...bounds.map((b) => b.left + b.width), 100);
    let maxY = Math.max(view.top + view.height, ...bounds.map((b) => b.top + b.height), 100);
    const pad = 30; minX -= pad; minY -= pad; maxX += pad; maxY += pad;
    const scale = Math.min((w - 12) / (maxX - minX), (h - 12) / (maxY - minY));
    const ox = (w - (maxX - minX) * scale) / 2;
    const oy = (h - (maxY - minY) * scale) / 2;
    ctx.fillStyle = "#b8c2d3";
    bounds.forEach((b) => ctx.fillRect(ox + (b.left - minX) * scale, oy + (b.top - minY) * scale, Math.max(2, b.width * scale), Math.max(2, b.height * scale)));
    ctx.strokeStyle = "#655bf2"; ctx.lineWidth = 1.5;
    ctx.strokeRect(ox + (view.left - minX) * scale, oy + (view.top - minY) * scale, Math.max(3, view.width * scale), Math.max(3, view.height * scale));
    mini.dataset.minX = String(minX); mini.dataset.minY = String(minY); mini.dataset.scale = String(scale); mini.dataset.offsetX = String(ox); mini.dataset.offsetY = String(oy);
  }, []);

  function navigateFromMinimap(event) {
    const canvas = canvasRef.current, mini = minimapElement.current;
    if (!canvas || !mini) return;
    const rect = mini.getBoundingClientRect();
    const px = (event.clientX - rect.left) * (mini.width / rect.width);
    const py = (event.clientY - rect.top) * (mini.height / rect.height);
    const scale = Number(mini.dataset.scale), minX = Number(mini.dataset.minX), minY = Number(mini.dataset.minY);
    const ox = Number(mini.dataset.offsetX), oy = Number(mini.dataset.offsetY);
    if (!scale) return;
    const worldX = (px - ox) / scale + minX, worldY = (py - oy) / scale + minY;
    const zoom = getZoomLevel(canvas), vpt = canvas.viewportTransform;
    vpt[4] = canvas.getWidth() / 2 - worldX * zoom;
    vpt[5] = canvas.getHeight() / 2 - worldY * zoom;
    canvas.setViewportTransform(vpt); canvas.requestRenderAll();
    setZoomPercent(Math.round(zoom * 100));
  }

  useEffect(() => {
    const canvas = new Canvas(canvasElement.current, {
      width: W,
      height: H,
      backgroundColor: BG,
      preserveObjectStacking: true,
      selection: true,
      enablePointerEvents: true,
    });
    canvasRef.current = canvas;
    installBrush(canvas, "pen", brushSettingsRef.current);

    const onSelection = (e) => updateSelected(e.selected?.[0] || canvas.getActiveObject());
    const onClearSelection = () => updateSelected(null);
    const onModified = () => {
      updateSelected(canvas.getActiveObject());
      saveHistory();
    };
    const onPathCreated = (e) => {
      if (!e.path) return;
      const s = brushSettingsRef.current;
      e.path.isPixelForgeStroke = true;
      e.path.pixelForgeObjectType = "stroke";
      e.path.brushKind = modeRef.current === "draw" ? s.kind : "highlighter";
      e.path.brushColor = s.color;
      e.path.brushWidth = s.width;
      e.path.brushOpacity = s.opacity;
      e.path.pressureEnabled = s.pressureEnabled;

      // Fabric turns the live brush stroke into a Path after pointer-up.
      // Canvas globalAlpha only affects the live preview, so save alpha in
      // the actual path stroke color as rgba() as well.
      if (modeRef.current === "highlighter") {
        e.path.set({
          stroke: colorWithAlpha(s.color, 0.30),
          opacity: 1,
          objectCaching: false,
        });
        e.path.dirty = true;
      }

      e.path.selectable = true;
      e.path.evented = true;
      saveHistory();
    };

    const eraseWholeStrokeAt = (point) => {
      const objects = canvas.getObjects().slice().reverse();
      const target = objects.find((obj) =>
        obj.isPixelForgeStroke &&
        obj.containsPoint(point)
      );
      if (target) {
        canvas.remove(target);
        canvas.requestRenderAll();
        setStatus("Whole stroke erased.");
        saveHistory();
      }
    };

    const eraseSweepAt = (point) => {
      const radius = eraserWidth;
      const objects = canvas.getObjects().slice().reverse();
      const targets = objects.filter((obj) => {
        if (!obj.isPixelForgeStroke) return false;
        const center = obj.getCenterPoint();
        const bounds = obj.getBoundingRect();
        const nearestX = Math.max(bounds.left, Math.min(point.x, bounds.left + bounds.width));
        const nearestY = Math.max(bounds.top, Math.min(point.y, bounds.top + bounds.height));
        const dx = point.x - nearestX;
        const dy = point.y - nearestY;
        const nearBounds = dx * dx + dy * dy <= radius * radius;
        const centerNear = Math.hypot(center.x - point.x, center.y - point.y) <= radius + Math.max(bounds.width, bounds.height) / 2;
        return nearBounds || centerNear;
      });
      if (targets.length) {
        targets.forEach((obj) => canvas.remove(obj));
        canvas.requestRenderAll();
        saveHistory();
      }
    };

    const onMouseDown = (event) => {
      const currentMode = modeRef.current;
      const target = event.target;
      const point = getWorldPointer(canvas, event.e);

      // Pan changes only the viewport transform; canvas objects keep their world coordinates.
      if (currentMode === "hand" || spaceDownRef.current) {
        panRef.current = {
          active: true,
          lastX: event.e.clientX,
          lastY: event.e.clientY,
        };
        canvas.discardActiveObject();
        canvas.selection = false;
        canvas.defaultCursor = "grabbing";
        canvas.requestRenderAll();
        event.e.preventDefault?.();
        return;
      }

      if (currentMode === "eraser") {
        if (eraserMode === "whole") {
          eraseWholeStrokeAt(point);
        } else {
          eraserRef.current.active = true;
          eraserRef.current.lastPoint = point;
          eraseSweepAt(point);
        }
        return;
      }

      if (currentMode === "lasso") {
        const preview = new Path(`M ${point.x} ${point.y}`, {
          fill: "rgba(101,91,242,0.08)", stroke: "#655bf2", strokeWidth: 2,
          strokeDashArray: [6, 4], objectCaching: false, selectable: false, evented: false,
        });
        preview.isPixelForgeLassoPreview = true;
        canvas.add(preview);
        lassoRef.current = { active: true, points: [point], preview };
        canvas.selection = false;
        canvas.requestRenderAll();
        return;
      }

      if (currentMode === "shape") {
        const start = { x: point.x, y: point.y };
        const common = { left: point.x, top: point.y, fill: "rgba(0,0,0,0)", stroke: brushSettingsRef.current.color, strokeWidth: brushSettingsRef.current.width, objectCaching: false, transparentCorners: false };
        let preview;
        const customPath = pathForShape(shapeToolRef.current);
        if (shapeToolRef.current === "ellipse" || shapeToolRef.current === "circle") preview = new Ellipse({ ...common, rx: 1, ry: 1 });
        else if (shapeToolRef.current === "triangle") preview = new Triangle({ ...common, width: 1, height: 1 });
        else if (shapeToolRef.current === "line") preview = new Line([point.x, point.y, point.x, point.y], { ...common, fill: "", strokeLineCap: "round" });
        else if (shapeToolRef.current === "roundedRect") preview = new Rect({ ...common, width: 1, height: 1, rx: 14, ry: 14 });
        else if (customPath) preview = new Path(customPath, { ...common, left: point.x, top: point.y, scaleX: 0.01, scaleY: 0.01, fill: "rgba(0,0,0,0)" });
        else preview = new Rect({ ...common, width: 1, height: 1 });
        preview.pixelForgeObjectType = "shape";
        preview.shapeKind = shapeToolRef.current;
        canvas.add(preview);
        shapeDrawRef.current = { active: true, start, preview };
        canvas.setActiveObject(preview);
        return;
      }

      if (currentMode === "curve") {
        const points = curvePointsRef.current;
        points.push({ x: point.x, y: point.y });
        if (points.length >= 2) {
          const oldPreview = curvePreviewRef.current;
          if (oldPreview) canvas.remove(oldPreview);
          const linePath = lineToolRef.current === "hinged"
            ? points.map((p, i) => `${i ? "L" : "M"} ${p.x} ${p.y}`).join(" ")
            : lineToolRef.current === "wavy" ? wavyPathFromPoints(points) : curvePathFromPoints(points);
          const path = new Path(linePath, {
            fill: "", stroke: brushSettingsRef.current.color, strokeWidth: brushSettingsRef.current.width,
            objectCaching: false, selectable: false, evented: false, strokeLineCap: "round", strokeLineJoin: "round"
          });
          path.pixelForgeObjectType = "curve";
          path.isPixelForgeCurve = true;
          curvePreviewRef.current = path;
          canvas.add(path);
          canvas.requestRenderAll();
        }
        setStatus(`Curve: ${points.length} control point(s). Add at least 3, then click Finish curve.`);
        return;
      }

      if (currentMode !== "text" || target) return;

      const settings = textSettingsRef.current;
      const text = new Textbox("Type something...", {
        left: point.x,
        top: point.y,
        width: 260,
        fontFamily: settings.fontFamily,
        fontSize: settings.fontSize,
        fill: settings.textColor,
        fontWeight: settings.bold ? "bold" : "normal",
        fontStyle: settings.italic ? "italic" : "normal",
        underline: settings.underline,
        textAlign: settings.textAlign,
        backgroundColor: settings.textBackground === "transparent" ? "" : settings.textBackground,
        lineHeight: Number(settings.lineSpacing),
        editable: true,
        splitByGrapheme: true,
        objectCaching: false,
        padding: 3,
      });
      text.isPixelForgeText = true;
      text.pixelForgeObjectType = "text";
      canvas.add(text);
      canvas.setActiveObject(text);
      text.enterEditing();
      text.selectAll();
      canvas.requestRenderAll();
      setModeAndRef("select");
      setStatus("Text created. Type to replace the placeholder.");
      saveHistory();
    };

    const onMouseMove = (event) => {
      if (panRef.current.active) {
        const dx = event.e.clientX - panRef.current.lastX;
        const dy = event.e.clientY - panRef.current.lastY;
        panRef.current.lastX = event.e.clientX;
        panRef.current.lastY = event.e.clientY;
        pendingPanRef.current.dx += dx;
        pendingPanRef.current.dy += dy;
        // Pointer events can arrive faster than the display refresh rate. Apply
        // all accumulated movement once per frame to avoid redundant renders.
        if (panFrameRef.current == null) {
          panFrameRef.current = window.requestAnimationFrame(() => {
            panFrameRef.current = null;
            const pending = pendingPanRef.current;
            pendingPanRef.current = { dx: 0, dy: 0 };
            const currentCanvas = canvasRef.current;
            if (!currentCanvas || (!pending.dx && !pending.dy)) return;
            const vpt = currentCanvas.viewportTransform;
            vpt[4] += pending.dx;
            vpt[5] += pending.dy;
            currentCanvas.setViewportTransform(vpt);
            currentCanvas.requestRenderAll();
            updateFloatingToolbar(currentCanvas.getActiveObject());
          });
        }
        return;
      }
      if (lassoRef.current.active) {
        const point = getWorldPointer(canvas, event.e);
        const lasso = lassoRef.current;
        const last = lasso.points[lasso.points.length - 1];
        if (!last || Math.hypot(point.x - last.x, point.y - last.y) >= 3) lasso.points.push(point);
        if (lasso.preview && lasso.points.length >= 2) {
          canvas.remove(lasso.preview);
          const pathData = lasso.points.map((p, index) => `${index ? "L" : "M"} ${p.x} ${p.y}`).join(" ");
          lasso.preview = new Path(pathData, {
            fill: "rgba(101,91,242,0.08)", stroke: "#655bf2", strokeWidth: 2,
            strokeDashArray: [6, 4], objectCaching: false, selectable: false, evented: false,
          });
          lasso.preview.isPixelForgeLassoPreview = true;
          canvas.add(lasso.preview);
        }
        canvas.requestRenderAll();
        return;
      }

      if (shapeDrawRef.current.active && shapeDrawRef.current.preview) {
        const { start, preview } = shapeDrawRef.current;
        const point = getWorldPointer(canvas, event.e);
        const left = Math.min(start.x, point.x), top = Math.min(start.y, point.y);
        const width = Math.max(1, Math.abs(point.x - start.x)), height = Math.max(1, Math.abs(point.y - start.y));
        if (preview.type === "line") preview.set({ x1: start.x, y1: start.y, x2: point.x, y2: point.y });
        else if (preview.type === "ellipse") preview.set({ left, top, rx: width / 2, ry: height / 2 });
        else if (preview.type === "path") preview.set({ left, top, scaleX: width / 100, scaleY: height / 100 });
        else preview.set({ left, top, width, height });
        preview.setCoords();
        canvas.requestRenderAll();
        return;
      }
      if (modeRef.current === "curve" && curvePointsRef.current.length >= 2) {
        const point = getWorldPointer(canvas, event.e);
        const points = [...curvePointsRef.current, point];
        const oldPreview = curvePreviewRef.current;
        if (oldPreview) canvas.remove(oldPreview);
        const linePath = lineToolRef.current === "hinged"
          ? points.map((p, i) => `${i ? "L" : "M"} ${p.x} ${p.y}`).join(" ")
          : lineToolRef.current === "wavy" ? wavyPathFromPoints(points) : curvePathFromPoints(points);
        const path = new Path(linePath, {
          fill: "", stroke: brushSettingsRef.current.color, strokeWidth: brushSettingsRef.current.width,
          objectCaching: false, selectable: false, evented: false, strokeLineCap: "round", strokeLineJoin: "round"
        });
        path.pixelForgeObjectType = "curve-preview";
        curvePreviewRef.current = path;
        canvas.add(path);
        canvas.requestRenderAll();
        return;
      }
      if (modeRef.current !== "eraser" || eraserMode !== "sweep" || !eraserRef.current.active) return;
      const point = getWorldPointer(canvas, event.e);
      const last = eraserRef.current.lastPoint;
      const steps = last ? Math.max(1, Math.ceil(Math.hypot(point.x - last.x, point.y - last.y) / Math.max(4, eraserWidth / 2))) : 1;
      for (let i = 1; i <= steps; i++) {
        const p = last
          ? { x: last.x + (point.x - last.x) * i / steps, y: last.y + (point.y - last.y) * i / steps }
          : point;
        eraseSweepAt(p);
      }
      eraserRef.current.lastPoint = point;
    };
    const onMouseUp = () => {
      panRef.current.active = false;
      if (lassoRef.current.active) {
        const { points, preview } = lassoRef.current;
        lassoRef.current = { active: false, points: [], preview: null };
        if (preview) canvas.remove(preview);
        const polygon = points.length >= 3 ? points : [];
        const inside = (x, y) => {
          let result = false;
          for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            const a = polygon[i], b = polygon[j];
            const crosses = ((a.y > y) !== (b.y > y)) && (x < ((b.x - a.x) * (y - a.y)) / ((b.y - a.y) || 1e-9) + a.x);
            if (crosses) result = !result;
          }
          return result;
        };
        const selected = polygon.length >= 3
          ? canvas.getObjects().filter((obj) => !obj.isPixelForgeLassoPreview && !obj.isGridHelper && inside(obj.getCenterPoint().x, obj.getCenterPoint().y))
          : [];
        canvas.discardActiveObject();
        if (selected.length === 1) canvas.setActiveObject(selected[0]);
        else if (selected.length > 1) canvas.setActiveObject(new ActiveSelection(selected, { canvas }));
        setModeAndRef("select");
        canvas.requestRenderAll();
        if (selected.length) {
          setStatus(`Lasso selected ${selected.length} object(s). Use Group selection to combine them, including pen strokes.`);
          saveHistory();
        } else setStatus("Lasso finished. No object centers were inside the selection.");
        return;
      }
      if (shapeDrawRef.current.active) {
        const preview = shapeDrawRef.current.preview;
        shapeDrawRef.current = { active: false, start: null, preview: null };
        if (preview) {
          preview.set({ selectable: true, evented: true });
          preview.setCoords();
          canvas.setActiveObject(preview);
          saveHistory();
          setStatus("Shape added with transparent fill. Select it to move, resize, or rotate.");
        }
      }
      eraserRef.current.active = false;
      eraserRef.current.lastPoint = null;
      if (modeRef.current === "hand") canvas.defaultCursor = "grab";
      else if (!spaceDownRef.current) canvas.defaultCursor = modeRef.current === "text" ? "text" : modeRef.current === "draw" || modeRef.current === "highlighter" ? "crosshair" : modeRef.current === "eraser" ? "cell" : "default";
      canvas.selection = modeRef.current === "select" || modeRef.current === "text";
    };

    const onMouseWheel = (event) => {
      const e = event.e;
      let zoom = getZoomLevel(canvas);
      zoom = clampZoom(zoom * Math.pow(0.999, e.deltaY));
      canvas.zoomToPoint(new Point(e.offsetX, e.offsetY), zoom);
      setZoomPercent(Math.round(zoom * 100));
      updateFloatingToolbar(canvas.getActiveObject());
      e.preventDefault();
      e.stopPropagation();
    };

    const onDoubleClick = (event) => {
      const target = event.target;
      if (target?.isPixelForgeLocked) {
        setStatus("This object is locked. Its creator or a canvas admin must unlock it before editing.");
        return;
      }
      if (target?.isPixelForgeText && typeof target.enterEditing === "function") {
        canvas.setActiveObject(target);
        target.enterEditing();
        target.selectAll();
        canvas.requestRenderAll();
      }
    };

    canvas.on("selection:created", onSelection);
    canvas.on("selection:updated", onSelection);
    canvas.on("selection:cleared", onClearSelection);
    canvas.on("object:modified", onModified);
    const onObjectMoving = (event) => {
      const obj = event.target;
      if (!obj) return;
      if (snapEnabledRef.current) {
        const grid = 25;
        obj.set({ left: Math.round((obj.left || 0) / grid) * grid, top: Math.round((obj.top || 0) / grid) * grid });
        obj.setCoords();
      }
      updateFloatingToolbar(obj);
    };
    // Draw the grid before Fabric paints objects so it stays behind the artwork.
    const onBeforeRender = () => drawGrid(canvas);
    const onAfterRender = () => drawMinimap();
    canvas.on("object:moving", onObjectMoving);
    canvas.on("before:render", onBeforeRender);
    canvas.on("after:render", onAfterRender);
    canvas.on("path:created", onPathCreated);
    canvas.on("mouse:down", onMouseDown);
    canvas.on("mouse:move", onMouseMove);
    canvas.on("mouse:up", onMouseUp);
    canvas.on("mouse:wheel", onMouseWheel);
    canvas.on("mouse:dblclick", onDoubleClick);
    const onObjectAdded = (event) => {
      const obj = event.target;
      if (!obj || obj.isPixelForgeLassoPreview || obj.isGridHelper) return;
      if (!obj.createdById) obj.createdById = currentUserIdRef.current;
    };
    canvas.on("object:added", onObjectAdded);

    historyRef.current.undo = [JSON.stringify(canvas.toJSON(EXTRA_PROPS))];
    syncHistoryButtons();

    return () => {
      window.clearTimeout(historyTimer.current);
      if (panFrameRef.current != null) window.cancelAnimationFrame(panFrameRef.current);
      panFrameRef.current = null;
      pendingPanRef.current = { dx: 0, dy: 0 };
      canvas.off("object:moving", onObjectMoving);
      canvas.off("before:render", onBeforeRender);
      canvas.off("after:render", onAfterRender);
      canvas.off("object:added", onObjectAdded);
      canvas.dispose();
      canvasRef.current = null;
    };
    // Canvas is intentionally initialized once; callbacks read current values from refs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  // Yjs object-level collaboration: each canvas object is a separate CRDT entry.
  // Socket.IO relays Yjs updates; IndexedDB keeps the Y.Doc available offline.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;

    const doc = new Y.Doc();
    const objectsMap = doc.getMap("canvasObjects");
    const versions = doc.getArray("canvasVersions");
    const cursors = new Map();
    const persistence = new IndexeddbPersistence(`pixelforge:${roomId}`, doc);
    const socket = io(serverUrl, { autoConnect: false, transports: ["websocket", "polling"] });
    const state = collaborationRef.current;
    state.doc = doc;
    state.objects = objectsMap;
    state.socket = socket;
    state.cursors = cursors;

    const userId = currentUserIdRef.current;
    const room = String(roomId || "pixelforge-demo").trim().slice(0, 100);

    const serializeObject = (obj) => {
      if (!obj || obj.isPixelForgeLassoPreview || obj.isGridHelper || obj.isPixelForgeCurvePreview || obj.isPixelForgeShapePreview) return null;
      if (!obj.pixelForgeSyncId) obj.pixelForgeSyncId = `${userId}-${crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
      try { return JSON.parse(JSON.stringify(obj.toObject(EXTRA_PROPS))); } catch { return null; }
    };

    const publishObject = (obj) => {
      if (state.applyingRemote || !socket.connected) {
        // Yjs also accepts offline writes; the socket reconnect will send them.
      }
      if (state.applyingRemote) return;
      const json = serializeObject(obj);
      if (!json || !json.pixelForgeSyncId) return;
      doc.transact(() => objectsMap.set(json.pixelForgeSyncId, {
        json,
        updatedBy: currentUserIdRef.current,
        updatedAt: Date.now(),
      }), "local-canvas");
      socket.emit("pf:cursor", { room, userId: currentUserIdRef.current, x: null, y: null, name: currentUserIdRef.current });
    };

    const removeObject = (obj) => {
      if (state.applyingRemote || !obj?.pixelForgeSyncId) return;
      objectsMap.delete(obj.pixelForgeSyncId);
    };

    const onMapChange = async (event) => {
      if (state.applyingRemote) return;
      state.applyingRemote = true;
      try {
        for (const [id, change] of event.changes.keys) {
          if (change.action === "delete") {
            const existing = canvas.getObjects().find((o) => o.pixelForgeSyncId === id);
            if (existing) canvas.remove(existing);
            continue;
          }
          const entry = objectsMap.get(id);
          if (!entry?.json) continue;
          const existing = canvas.getObjects().find((o) => o.pixelForgeSyncId === id);
          if (existing && entry.updatedBy === currentUserIdRef.current) continue;
          const enlivened = await fabricUtil.enlivenObjects([entry.json]);
          const next = enlivened?.[0];
          if (!next) continue;
          next.pixelForgeSyncId = id;
          if (existing) canvas.remove(existing);
          canvas.add(next);
        }
        canvas.requestRenderAll();
      } catch (error) {
        console.error("Could not apply remote canvas update:", error);
      } finally {
        state.applyingRemote = false;
      }
    };

    const onDocUpdate = (update, origin) => {
      if (origin === "socket") return;
      if (socket.connected) socket.emit("pf:y-update", { room, update: Array.from(update) });
    };
    const onSocketUpdate = ({ update }) => {
      if (!Array.isArray(update)) return;
      Y.applyUpdate(doc, new Uint8Array(update), "socket");
    };
    const onSocketAwareness = (payload) => {
      if (!payload || payload.userId === currentUserIdRef.current) return;
      setRemoteCursors((prev) => {
        const next = prev.filter((c) => c.userId !== payload.userId);
        if (Number.isFinite(payload.x) && Number.isFinite(payload.y)) next.push({ color: payload.userId === "user-2" ? "#e85d75" : "#16a085", activity: "active", ...payload });
        return next;
      });
    };
    const onCursorMove = (event) => {
      if (!socket.connected) return;
      const rect = canvas.upperCanvasEl?.getBoundingClientRect();
      if (!rect) return;
      const x = event.e.clientX - rect.left;
      const y = event.e.clientY - rect.top;
      setLocalCursor({ x, y });
      socket.emit("pf:cursor", {
        room, userId: currentUserIdRef.current, name: currentUserIdRef.current,
        color: currentUserIdRef.current === "user-2" ? "#e85d75" : "#655bf2",
        activity: modeRef.current === "draw" || modeRef.current === "highlighter" ? "drawing" : modeRef.current === "hand" ? "navigating" : "active",
        x, y,
      });
    };
    const onPong = (payload = {}) => {
      const sentAt = Number(payload.sentAt || lastPingAt);
      if (sentAt) setLatencyMs(Math.max(0, performance.now() - sentAt));
    };
    const onSocketConnect = () => {
      setCollabStatus("Connected");
      socket.emit("pf:join", { room, userId: currentUserIdRef.current });
      socket.emit("pf:y-update", { room, update: Array.from(Y.encodeStateAsUpdate(doc)) });
    };
    const onSocketDisconnect = () => setCollabStatus("Offline (changes saved locally)");
    const onVersion = () => {
      const snapshot = JSON.stringify(canvas.toJSON(EXTRA_PROPS));
      const last = versions.length ? versions.get(versions.length - 1) : null;
      if (!last || last.snapshot !== snapshot) {
        const revision = { id: `v-${Date.now()}`, createdAt: Date.now(), createdBy: currentUserIdRef.current, snapshot };
        versions.push([revision]);
        setRevisions((prev) => [revision, ...prev].slice(0, 100));
      }
    };

    objectsMap.observe(onMapChange);
    doc.on("update", onDocUpdate);
    socket.on("pf:y-update", onSocketUpdate);
    socket.on("pf:cursor", onSocketAwareness);
    socket.on("pf:pong", onPong);
    socket.on("connect", onSocketConnect);
    socket.on("disconnect", onSocketDisconnect);
    const onLocalObjectAdded = (e) => { publishObject(e.target); onVersion(); };
    const onLocalObjectModified = (e) => { publishObject(e.target); onVersion(); };
    const onLocalObjectRemoved = (e) => removeObject(e.target);
    canvas.on("object:added", onLocalObjectAdded);
    canvas.on("object:modified", onLocalObjectModified);
    canvas.on("object:removed", onLocalObjectRemoved);
    canvas.on("mouse:move", onCursorMove);
    socket.connect();

    // Seed Yjs from objects already on the canvas after local IndexedDB has loaded.
    persistence.whenSynced.then(() => {
      setRevisions((versions.toArray() || []).slice().reverse());
      if (objectsMap.size === 0) {
        canvas.getObjects().forEach((obj) => publishObject(obj));
      }
    });

    return () => {
      objectsMap.unobserve(onMapChange);
      doc.off("update", onDocUpdate);
      socket.off("pf:y-update", onSocketUpdate);
      socket.off("pf:cursor", onSocketAwareness);
      socket.off("pf:pong", onPong);
      socket.off("connect", onSocketConnect);
      socket.off("disconnect", onSocketDisconnect);
      canvas.off("object:added", onLocalObjectAdded);
      canvas.off("object:modified", onLocalObjectModified);
      canvas.off("object:removed", onLocalObjectRemoved);
      canvas.off("mouse:move", onCursorMove);
      socket.disconnect();
      persistence.destroy();
      doc.destroy();
      collaborationRef.current = { doc: null, objects: null, socket: null, applyingRemote: false, cursors: null };
    };
  }, [roomId, serverUrl]);

  // Current settings are copied to refs each render so the Fabric listeners stay fresh.
  currentUserIdRef.current = currentUserId;
  shapeToolRef.current = shapeTool;
  lineToolRef.current = lineTool;
  textSettingsRef.current = {
    fontFamily, fontSize, textColor, bold, italic, underline, textAlign,
    textBackground, lineSpacing,
  };
 brushSettingsRef.current = {
  kind: brushKind,
  color: mode === "highlighter" ? highlighterColor : brushColor,
  width: mode === "highlighter"
    ? Math.max(brushWidth, 18)
    : brushWidth,
  opacity: mode === "highlighter"
    ? 0.30
    : brushOpacity,
  pressureEnabled,
};

  // Keep the Fabric brush in sync with the active brush selection.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (mode === "draw" || mode === "highlighter") {
      installBrush(canvas, mode === "highlighter" ? "highlighter" : brushKind, brushSettingsRef.current);
      canvas.isDrawingMode = true;
    } else {
      canvas.isDrawingMode = false;
    }
    canvas.requestRenderAll();
  }, [mode, brushKind, brushColor, brushWidth, brushOpacity, highlighterColor, pressureEnabled, installBrush]);

  function setModeAndRef(next) {
    modeRef.current = next;
    setMode(next);
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.isDrawingMode = next === "draw" || next === "highlighter";
    canvas.selection = next === "select" || next === "text";
    canvas.defaultCursor =
      next === "hand" ? "grab" :
      next === "text" ? "text" :
      next === "draw" || next === "highlighter" || next === "shape" || next === "curve" ? "crosshair" :
      next === "eraser" ? "cell" : "default";

    canvas.getObjects().forEach((obj) => {
      if (next === "draw" || next === "highlighter" || next === "eraser" || next === "hand" || next === "shape" || next === "curve") {
        obj.selectable = false;
        obj.evented = false;
      } else {
        obj.selectable = true;
        obj.evented = true;
      }
    });
    canvas.requestRenderAll();
  }

  function applyTextStyle(patch) {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (active?.isPixelForgeLocked) {
      setStatus("This text is locked. Unlock it before formatting.");
      return;
    }
    if (!canvas || !active || !active.isPixelForgeText) {
      setStatus("Select standalone canvas text to format it. Sticky-note header/body styling remains in the designer.");
      return;
    }
    active.set(patch);
    active.setCoords();
    canvas.requestRenderAll();
    updateSelected(active);
    saveHistory();
  }

  function changeFontFamily(v) { setFontFamily(v); applyTextStyle({ fontFamily: v }); }
  function changeFontSize(v) { setFontSize(Number(v)); applyTextStyle({ fontSize: Number(v) }); }
  function changeTextColor(v) { setTextColor(v); applyTextStyle({ fill: v }); }
  function changeBold() { const v = !bold; setBold(v); applyTextStyle({ fontWeight: v ? "bold" : "normal" }); }
  function changeItalic() { const v = !italic; setItalic(v); applyTextStyle({ fontStyle: v ? "italic" : "normal" }); }
  function changeUnderline() { const v = !underline; setUnderline(v); applyTextStyle({ underline: v }); }
  function changeAlign(v) { setTextAlign(v); applyTextStyle({ textAlign: v }); }
  function changeTextBackground(v) { setTextBackground(v); applyTextStyle({ backgroundColor: v === "transparent" ? "" : v }); }
  function changeLineSpacing(v) { setLineSpacing(Number(v)); applyTextStyle({ lineHeight: Number(v) }); }

  function highlightSelectedCharacters(color = highlighterColor) {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (active?.isPixelForgeLocked) {
      setStatus("This text is locked. Unlock it before editing its highlight.");
      return;
    }
    if (!active || !active.isPixelForgeText || !active.isEditing) {
      setStatus("To highlight selected characters, double-click standalone text, select characters, then choose Text Highlight.");
      return;
    }
    const start = active.selectionStart;
    const end = active.selectionEnd;
    if (start === end) {
      setStatus("Select one or more characters inside the text before highlighting.");
      return;
    }
    // Fabric.js IText/Textbox styles are indexed by line and character.
    const lines = active.text.split(/\r?\n/);
    const styles = { ...(active.styles || {}) };
    let globalIndex = 0;
    lines.forEach((line, lineIndex) => {
      const lineStyles = { ...(styles[lineIndex] || {}) };
      for (let charIndex = 0; charIndex < line.length; charIndex++) {
        if (globalIndex >= start && globalIndex < end) {
          lineStyles[charIndex] = { ...(lineStyles[charIndex] || {}), textBackgroundColor: color };
        }
        globalIndex++;
      }
      styles[lineIndex] = lineStyles;
      if (lineIndex < lines.length - 1) globalIndex++;
    });
    active.set("styles", styles);
    active.initDimensions();
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Selected characters highlighted.");
  }

  function highlightWholeTextObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (active?.isPixelForgeLocked) {
      setStatus("This text is locked. Unlock it before editing its highlight.");
      return;
    }
    if (!active || !active.isPixelForgeText) {
      setStatus("Select a standalone text object first.");
      return;
    }
    active.set("backgroundColor", highlighterColor);
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Whole text object highlighted.");
  }

  function finishCurve() {
    const canvas = canvasRef.current;
    const points = curvePointsRef.current;
    const preview = curvePreviewRef.current;
    if (!canvas || points.length < 2 || !preview) {
      setStatus("Add at least 2 control points to finish a line.");
      return;
    }
    canvas.remove(preview);
    const finalPath = lineToolRef.current === "hinged"
      ? points.map((p, i) => `${i ? "L" : "M"} ${p.x} ${p.y}`).join(" ")
      : lineToolRef.current === "wavy" ? wavyPathFromPoints(points) : curvePathFromPoints(points);
    const curve = new Path(finalPath, {
      fill: "", stroke: brushSettingsRef.current.color, strokeWidth: brushSettingsRef.current.width,
      objectCaching: false, selectable: true, evented: true, strokeLineCap: "round", strokeLineJoin: "round"
    });
    curve.pixelForgeObjectType = "curve";
    curve.isPixelForgeCurve = true;
    canvas.add(curve);
    canvas.setActiveObject(curve);
    curvePointsRef.current = [];
    curvePreviewRef.current = null;
    setModeAndRef("select");
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Smooth curve added. It uses your control points and can be selected like other objects.");
  }

  async function addImageToCanvas(event) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    // Reset the input so selecting the same file twice also triggers onChange.
    input.value = "";
    const canvas = canvasRef.current;
    if (!file || !canvas) return;

    const allowedTypes = ["image/png", "image/jpeg", "image/webp", "image/gif"];
    if (!allowedTypes.includes(file.type)) {
      setStatus("Choose a PNG, JPG, WebP, or GIF image.");
      return;
    }
    const maxBytes = 8 * 1024 * 1024;
    if (file.size > maxBytes) {
      setStatus("This image is larger than 8 MB. Please choose a smaller file.");
      return;
    }

    setBusy(true);
    try {
      // Embed the image as a data URL for this local prototype. Fabric can then
      // serialize it into canvas JSON/history without relying on a temporary blob URL.
      const dataUrl = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = () => reject(new Error("The selected image could not be read."));
        reader.readAsDataURL(file);
      });
      const image = await FabricImage.fromURL(dataUrl);
      const originalWidth = image.width || 1;
      const originalHeight = image.height || 1;
      const scale = Math.min(1, 420 / originalWidth, 320 / originalHeight);
      const zoom = canvas.getZoom() || 1;
      const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
      const centerX = (canvas.getWidth() / 2 - vpt[4]) / zoom;
      const centerY = (canvas.getHeight() / 2 - vpt[5]) / zoom;

      image.set({
        left: centerX - (originalWidth * scale) / 2,
        top: centerY - (originalHeight * scale) / 2,
        scaleX: scale,
        scaleY: scale,
        objectCaching: true,
        transparentCorners: false,
        cornerColor: "#655bf2",
        borderColor: "#655bf2",
        pixelForgeObjectType: "image",
        imageName: file.name,
        imageMimeType: file.type,
      });
      canvas.add(image);
      canvas.setActiveObject(image);
      setModeAndRef("select");
      canvas.requestRenderAll();
      saveHistory();
      setStatus(`Added image “${file.name}”. Select it to move, resize, rotate, duplicate, or delete it.`);
    } catch (error) {
      console.error("Failed to add image to canvas:", error);
      setStatus("Could not add that image. Try another PNG, JPG, WebP, or GIF file.");
    } finally {
      setBusy(false);
    }
  }

  function addTableToCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rows = Math.max(2, Math.min(12, Number(tableRows) || 4));
    const cols = Math.max(2, Math.min(8, Number(tableCols) || 3));
    const cellW = 112, cellH = 34;
    const children = [];
    const labels = [];
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        children.push(new Rect({ left: c * cellW, top: r * cellH, width: cellW, height: cellH, fill: r === 0 ? "#e9e7ff" : "#ffffff", stroke: "#8b90a0", strokeWidth: 1, selectable: false, evented: false }));
        const value = r === 0 ? (c === 0 ? "Label" : `Column ${c + 1}`) : (c === 0 ? `Row ${r}` : "");
        labels.push(new Textbox(value, { left: c * cellW + 6, top: r * cellH + 7, width: cellW - 12, height: cellH - 10, fontSize: 13, fill: "#172033", fontFamily: "Arial", selectable: false, evented: false, editable: false }));
      }
    }
    const group = new Group([...children, ...labels], { left: 80, top: 80, subTargetCheck: false, objectCaching: false });
    group.set({ pixelForgeObjectType: "table", isPixelForgeTable: true, tableRows: rows, tableCols: cols, createdById: currentUserId, transparentCorners: false, cornerColor: "#655bf2", borderColor: "#655bf2" });
    canvas.add(group); canvas.setActiveObject(group); setModeAndRef("select"); canvas.requestRenderAll(); saveHistory();
    setStatus(`Added ${rows} × ${cols} table. Move or resize it like any canvas object.`);
  }

  function addGraphToCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const parsed = graphData.trim().split(/\r?\n/).map((line) => line.split(",").map((v) => v.trim()));
    const rows = parsed.slice(1).map((r, i) => ({ label: r[0] || `Item ${i + 1}`, value: Number(r[1]) })).filter((r) => Number.isFinite(r.value));
    if (!rows.length) { setStatus("Enter CSV data with a header row and numeric second column, for example Label,Value then A,12."); return; }
    const values = rows.map((r) => Math.max(0, r.value));
    const max = Math.max(1, ...values);
    const children = [];
    const width = 420, height = 270, leftPad = 42, bottomPad = 42, plotH = 180, plotW = 350;
    children.push(new Rect({ left: 0, top: 0, width, height, fill: "#ffffff", stroke: "#d6dbea", strokeWidth: 1, rx: 10, ry: 10, selectable: false, evented: false }));
    children.push(new Textbox(`${graphType.toUpperCase()} CHART`, { left: 14, top: 9, width: width - 28, height: 22, fontSize: 15, fontWeight: "bold", fill: "#303951", selectable: false, evented: false }));
    const colors = ["#655bf2", "#21a6a1", "#f59e0b", "#e85d75", "#3b82f6", "#8b5cf6", "#10b981", "#f97316"];
    const x0 = leftPad, y0 = 34 + plotH;
    children.push(new Line([x0, 34, x0, y0], { stroke: "#9aa3b5", strokeWidth: 1, selectable: false, evented: false }));
    children.push(new Line([x0, y0, x0 + plotW, y0], { stroke: "#9aa3b5", strokeWidth: 1, selectable: false, evented: false }));
    const step = plotW / rows.length;
    if (["bar", "horizontal-bar", "stacked-bar", "histogram"].includes(graphType)) {
      rows.forEach((row, i) => {
        const barH = values[i] / max * (plotH - 8);
        if (graphType === "horizontal-bar") {
          const bh = Math.max(10, (plotH / rows.length) - 6);
          const yy = 40 + i * (plotH / rows.length);
          children.push(new Rect({ left: x0, top: yy, width: values[i] / max * plotW, height: bh, fill: colors[i % colors.length], selectable: false, evented: false }));
          children.push(new Textbox(row.label, { left: 5, top: yy, width: 34, height: bh, fontSize: 9, fill: "#303951", selectable: false, evented: false }));
        } else {
          const bw = Math.max(8, step * 0.58), xx = x0 + i * step + (step - bw) / 2;
          children.push(new Rect({ left: xx, top: y0 - barH, width: bw, height: barH, fill: colors[i % colors.length], selectable: false, evented: false }));
          if (graphType === "stacked-bar") children.push(new Rect({ left: xx, top: y0 - barH * 0.35, width: bw, height: barH * 0.35, fill: colors[(i + 2) % colors.length], selectable: false, evented: false }));
          children.push(new Textbox(row.label, { left: xx - 8, top: y0 + 5, width: bw + 16, height: 28, fontSize: 10, textAlign: "center", fill: "#303951", selectable: false, evented: false }));
        }
      });
    } else if (["line", "area", "scatter", "radar", "wavy"].includes(graphType)) {
      const pts = rows.map((row, i) => ({ x: x0 + (rows.length === 1 ? plotW / 2 : i * plotW / (rows.length - 1)), y: y0 - values[i] / max * (plotH - 10) }));
      if (graphType === "area") children.push(new Polygon([{x:pts[0].x,y:y0}, ...pts, {x:pts[pts.length-1].x,y:y0}], { fill: "rgba(101,91,242,0.18)", stroke: "#655bf2", strokeWidth: 2, selectable: false, evented: false }));
      else if (pts.length > 1) children.push(new Path(pts.map((p,i)=>`${i===0?'M':'L'} ${p.x} ${p.y}`).join(" "), { fill: "", stroke: "#655bf2", strokeWidth: 3, selectable: false, evented: false }));
      pts.forEach((p,i) => { children.push(new Ellipse({ left:p.x-4, top:p.y-4, rx:4, ry:4, fill:colors[i%colors.length], stroke:"#ffffff", strokeWidth:1, selectable:false, evented:false })); children.push(new Textbox(rows[i].label,{left:p.x-22,top:y0+5,width:44,height:24,fontSize:9,textAlign:"center",fill:"#303951",selectable:false,evented:false})); });
    } else {
      const total = values.reduce((a,b)=>a+b,0) || 1;
      const cx = 210, cy = 145, radius = 82;
      let angle = -Math.PI/2;
      rows.forEach((row,i)=>{
        const next = angle + values[i] / total * Math.PI * 2;
        const points = [{x:cx,y:cy}];
        for(let a=angle;a<=next+0.001;a+=Math.max(0.02,(next-angle)/24)) points.push({x:cx+radius*Math.cos(a),y:cy+radius*Math.sin(a)});
        points.push({x:cx+radius*Math.cos(next),y:cy+radius*Math.sin(next)});
        children.push(new Polygon(points,{fill:colors[i%colors.length],stroke:"#ffffff",strokeWidth:1,selectable:false,evented:false}));
        angle=next;
      });
      if(graphType === "doughnut") children.push(new Ellipse({left:cx-38,top:cy-38,rx:38,ry:38,fill:"#ffffff",stroke:"#ffffff",selectable:false,evented:false}));
    }
    rows.forEach((row,i)=> children.push(new Textbox(`${row.label}: ${row.value}`, { left: 12 + (i % 2) * 200, top: height - 23 + Math.floor(i / 2) * 12, width: 190, height: 12, fontSize: 9, fill: colors[i % colors.length], selectable: false, evented: false })));
    const graph = new Group(children, { left: 100, top: 90, objectCaching: false });
    graph.set({ pixelForgeObjectType: "graph", isPixelForgeGraph: true, graphType, graphData: JSON.stringify(rows), createdById: currentUserId, transparentCorners: false, cornerColor: "#655bf2", borderColor: "#655bf2" });
    canvas.add(graph); canvas.setActiveObject(graph); setModeAndRef("select"); canvas.requestRenderAll(); saveHistory();
    setStatus(`Added ${graphType} chart with ${rows.length} data points. Select it to move, resize, rotate, or delete.`);
  }

  async function addDesignedStickyNote() {
    const canvas = canvasRef.current;
    if (!canvas || busy) return;
    setBusy(true);
    try {
      const note = await createStickyNote({
        template, header: header || "Title", body: body || "Write something...",
        left: 35 + Math.random() * 100, top: 35 + Math.random() * 80,
        width: noteWidth, height: noteHeight, headerFont, bodyFont,
        headerSize, bodySize,
        headerColor: headerColor || selectedTemplate.foreground,
        bodyColor: bodyColor || selectedTemplate.foreground,
      });
      canvas.add(note);
      canvas.setActiveObject(note);
      canvas.requestRenderAll();
      saveHistory();
      setStatus(`${selectedTemplate.name} added to canvas.`);
    } catch (error) {
      console.error(error);
      setStatus("Could not load note image. Check public/sticky-notes.");
    } finally {
      setBusy(false);
    }
  }

  function deleteSelectedObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) {
      setStatus("Select an object first.");
      return;
    }
    const selectedParts = canvas.getActiveObjects();
    if (selectedParts.some((object) => object.isPixelForgeLocked)) {
      setStatus("Unlock the selected object/group before deleting it.");
      return;
    }
    canvas.remove(active);
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Selected object deleted.");
  }

  async function duplicateSelectedObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) {
      setStatus("Select an object to duplicate.");
      return;
    }
    if (canvas.getActiveObjects().some((object) => object.isPixelForgeLocked)) {
      setStatus("Unlock the selected object/group before duplicating it.");
      return;
    }
    try {
      const clone = await active.clone(EXTRA_PROPS);
      clone.set({ left: (active.left || 0) + 24, top: (active.top || 0) + 24 });
      canvas.add(clone);
      canvas.setActiveObject(clone);
      canvas.requestRenderAll();
      saveHistory();
      setStatus("Object duplicated.");
    } catch (error) {
      console.error(error);
      setStatus("Could not duplicate this object.");
    }
  }

  function getSelectedObjects() {
    const canvas = canvasRef.current;
    if (!canvas) return [];
    const objects = canvas.getActiveObjects();
    return objects.length ? objects : [];
  }

  function visitObjectTree(object, callback) {
    if (!object) return;
    callback(object);
    if (typeof object.getObjects === "function") {
      object.getObjects().forEach((child) => visitObjectTree(child, callback));
    }
  }

  function setSelectedLock(locked) {
    const canvas = canvasRef.current;
    const selected = getSelectedObjects();
    if (!canvas || !selected.length) {
      setStatus("Select one or more objects to lock or unlock.");
      return;
    }
    const allParts = [];
    selected.forEach((object) => visitObjectTree(object, (part) => allParts.push(part)));
    const uniqueParts = [...new Set(allParts)];
    if (locked) {
      const notOwned = uniqueParts.find((part) => part.createdById && part.createdById !== currentUserId);
      if (notOwned && !adminOverride) {
        setStatus("Only the object creator can lock it in this prototype. Switch to its creator or use the admin override.");
        return;
      }
    } else {
      const notOwned = uniqueParts.find((part) => part.isPixelForgeLocked && part.createdById && part.createdById !== currentUserId);
      if (notOwned && !adminOverride) {
        setStatus("Only the creator can unlock these objects. A canvas admin can override this restriction.");
        return;
      }
    }
    uniqueParts.forEach((part) => {
      part.isPixelForgeLocked = locked;
      part.lockedById = locked ? part.createdById || currentUserId : null;
      part.set({
        lockMovementX: locked, lockMovementY: locked,
        lockScalingX: locked, lockScalingY: locked,
        lockRotation: locked, lockSkewingX: locked, lockSkewingY: locked,
        hasControls: !locked,
      });
      // Locked objects remain selectable so their creator/admin can unlock them.
      part.selectable = true;
      part.evented = true;
      part.setCoords?.();
    });
    canvas.requestRenderAll();
    saveHistory();
    setStatus(locked ? "Selected objects and all group components are locked." : (adminOverride ? "Admin override: selected objects and group components unlocked." : "Selected objects and group components unlocked."));
  }

  function groupSelectedObjects() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active || canvas.getActiveObjects().length < 2 || typeof active.toGroup !== "function") {
      setStatus("Select at least two objects together before grouping.");
      return;
    }
    if (canvas.getActiveObjects().some((object) => object.isPixelForgeLocked)) {
      setStatus("Unlock selected objects before grouping them.");
      return;
    }
    try {
      const group = active.toGroup();
      group.createdById = currentUserId;
      group.pixelForgeObjectType = "group";
      group.isPixelForgeGroup = true;
      canvas.setActiveObject(group);
      canvas.requestRenderAll();
      saveHistory();
      setStatus("Selected objects grouped.");
    } catch (error) {
      console.error("Grouping failed:", error);
      setStatus("Could not group this selection in the installed Fabric.js version.");
    }
  }

  function ungroupSelectedObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active || typeof active.toActiveSelection !== "function" || active.type !== "group") {
      setStatus("Select a group to ungroup it.");
      return;
    }
    if (active.isPixelForgeLocked || canvas.getActiveObjects().some((object) => object.isPixelForgeLocked)) {
      setStatus("Unlock this group before ungrouping it.");
      return;
    }
    try {
      const selection = active.toActiveSelection();
      canvas.setActiveObject(selection);
      canvas.requestRenderAll();
      saveHistory();
      setStatus("Group separated into individual objects.");
    } catch (error) {
      console.error("Ungrouping failed:", error);
      setStatus("Could not ungroup this object in the installed Fabric.js version.");
    }
  }

  function moveSelectedLayer(direction) {
    const canvas = canvasRef.current;
    const objects = getSelectedObjects();
    if (!canvas || !objects.length) {
      setStatus("Select one or more objects first.");
      return;
    }
    if (objects.some((object) => object.isPixelForgeLocked)) {
      setStatus("Unlock selected objects before changing their layer order.");
      return;
    }
    try {
      // Work on the individual selected objects, not the temporary ActiveSelection.
      const ordered = direction === "front" ? [...objects] : [...objects].reverse();
      ordered.forEach((object) => {
        if (direction === "front") canvas.bringObjectToFront(object);
        else canvas.sendObjectToBack(object);
      });
      canvas.requestRenderAll();
      saveHistory();
      setStatus(direction === "front" ? "Selected object(s) brought to front." : "Selected object(s) sent to back.");
    } catch (error) {
      console.error(error);
      setStatus("Could not change object layer order in this Fabric.js version.");
    }
  }

  function nudgeSelectedObjects(dx, dy) {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) return false;
    if (canvas.getActiveObjects().some((object) => object.isPixelForgeLocked)) {
      setStatus("Unlock selected objects before moving them.");
      return false;
    }
    // Move the active object/ActiveSelection as a unit so multi-select children
    // keep their relative positions and group transforms remain intact.
    active.set({ left: (active.left || 0) + dx, top: (active.top || 0) + dy });
    active.setCoords();
    canvas.requestRenderAll();
    saveHistory();
    setStatus(`Moved selection ${dx || 0} world units horizontally and ${dy || 0} vertically.`);
    return true;
  }

  function exportCanvasJSON() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const payload = { format: "pixelforge-canvas", version: 1, exportedAt: new Date().toISOString(), roomId, objects: canvas.toJSON(EXTRA_PROPS) };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = `pixelforge-${roomId || "canvas"}.json`; a.click();
    URL.revokeObjectURL(url);
    setStatus("Canvas JSON exported.");
  }

  async function importCanvasJSON(event) {
    const file = event.target.files?.[0];
    if (!file || !canvasRef.current) return;
    try {
      const parsed = JSON.parse(await file.text());
      const json = parsed?.format === "pixelforge-canvas" ? parsed.objects : parsed;
      if (!json || !Array.isArray(json.objects)) throw new Error("This file does not contain a Fabric canvas objects array.");
      await canvasRef.current.loadFromJSON(json);
      canvasRef.current.requestRenderAll();
      saveHistory();
      setStatus(`Canvas restored from ${file.name}.`);
    } catch (error) { setStatus(`Import failed: ${error.message}`); }
    event.target.value = "";
  }

  async function restoreRevision(revision) {
    if (!revision?.snapshot) return;
    await restoreSnapshot(revision.snapshot);
    setStatus(`Restored revision from ${new Date(revision.createdAt).toLocaleString()}.`);
    setRevisionCompare(null);
  }

  function compareRevision(revision) {
    const canvas = canvasRef.current;
    if (!revision?.snapshot || !canvas) return;
    try {
      const past = JSON.parse(revision.snapshot);
      const now = canvas.toJSON(EXTRA_PROPS);
      const pastObjects = past.objects || [];
      const nowObjects = now.objects || [];
      const ids = (arr) => new Set(arr.map((o) => o.pixelForgeSyncId).filter(Boolean));
      const a = ids(pastObjects), b = ids(nowObjects);
      setRevisionCompare({ revision, pastCount: pastObjects.length, currentCount: nowObjects.length, added: [...b].filter((id) => !a.has(id)).length, removed: [...a].filter((id) => !b.has(id)).length });
      setSelectedRevisionId(revision.id);
    } catch { setStatus("Could not compare this revision."); }
  }

  function sendLatencyPing() {
    const socket = collaborationRef.current.socket;
    if (!socket?.connected) { setStatus("Connect to the collaboration server to measure round-trip latency."); return; }
    const sentAt = performance.now(); setLastPingAt(sentAt);
    socket.emit("pf:ping", { sentAt, room: roomId, userId: currentUserIdRef.current });
    setStatus("Latency ping sent. Server must reply with pf:pong and the same sentAt value.");
  }

  function spatialVolume(cursor) {
    const dx = (cursor.x || 0) - localCursor.x;
    const dy = (cursor.y || 0) - localCursor.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    return Math.max(0, Math.min(1, 1 - distance / 900));
  }

  async function restoreSnapshot(snapshot) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    historyRef.current.restoring = true;
    try {
      await canvas.loadFromJSON(JSON.parse(snapshot));
      canvas.requestRenderAll();
    } finally {
      historyRef.current.restoring = false;
      syncHistoryButtons();
    }
  }

  async function undo() {
    const hist = historyRef.current;
    if (hist.undo.length <= 1) return;
    hist.redo.push(hist.undo.pop());
    await restoreSnapshot(hist.undo[hist.undo.length - 1]);
    setStatus("Undo complete.");
  }

  async function redo() {
    const hist = historyRef.current;
    if (!hist.redo.length) return;
    const snapshot = hist.redo.pop();
    hist.undo.push(snapshot);
    await restoreSnapshot(snapshot);
    setStatus("Redo complete.");
  }

  function zoomBy(factor) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const zoom = clampZoom(getZoomLevel(canvas) * factor);
    canvas.zoomToPoint(new Point(canvas.getWidth() / 2, canvas.getHeight() / 2), zoom);
    setZoomPercent(Math.round(getZoomLevel(canvas) * 100));
    canvas.requestRenderAll();
  }

  function resetView() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    setZoomPercent(100);
    canvas.requestRenderAll();
  }

  function clearCanvas() {
    const canvas = canvasRef.current;
    if (!canvas || !window.confirm("Clear all canvas objects?")) return;
    canvas.clear();
    canvas.backgroundColor = BG;
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Canvas cleared.");
  }

  useEffect(() => {
    const onKeyDown = (event) => {
      const canvas = canvasRef.current;
      const active = canvas?.getActiveObject();
      if (!canvas || active?.isEditing || ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;
      if (event.key === "Enter" && modeRef.current === "curve") {
        event.preventDefault();
        finishCurve();
        return;
      }
      if (event.key === "Escape" && modeRef.current === "curve") {
        event.preventDefault();
        if (curvePreviewRef.current) canvas.remove(curvePreviewRef.current);
        curvePreviewRef.current = null;
        curvePointsRef.current = [];
        canvas.requestRenderAll();
        setModeAndRef("select");
        setStatus("Line cancelled.");
        return;
      }
      if (event.code === "Space" && canvas.upperCanvasEl?.matches(":hover")) {
        event.preventDefault();
        spaceDownRef.current = true;
        canvas.defaultCursor = "grab";
        canvas.selection = false;
        return;
      }
      if ((event.key === "Delete" || event.key === "Backspace") && active) {
        event.preventDefault(); deleteSelectedObject();
      } else if (active && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
        // Shift + arrow moves by 10 world units; arrow alone moves by 1.
        const step = event.shiftKey ? 10 : 1;
        const delta = {
          ArrowUp: [0, -step], ArrowDown: [0, step],
          ArrowLeft: [-step, 0], ArrowRight: [step, 0],
        }[event.key];
        event.preventDefault();
        nudgeSelectedObjects(delta[0], delta[1]);
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "d") {
        event.preventDefault(); duplicateSelectedObject();
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z" && !event.shiftKey) {
        event.preventDefault(); undo();
      } else if ((event.ctrlKey || event.metaKey) && (event.key.toLowerCase() === "y" || (event.key.toLowerCase() === "z" && event.shiftKey))) {
        event.preventDefault(); redo();
      }
    };
    const onKeyUp = (event) => {
      if (event.code !== "Space") return;
      spaceDownRef.current = false;
      panRef.current.active = false;
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.selection = modeRef.current === "select" || modeRef.current === "text";
      canvas.defaultCursor = modeRef.current === "hand" ? "grab" : modeRef.current === "text" ? "text" : modeRef.current === "draw" || modeRef.current === "highlighter" || modeRef.current === "shape" || modeRef.current === "curve" ? "crosshair" : modeRef.current === "eraser" ? "cell" : "default";
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  });

  useEffect(() => { gridVisibleRef.current = gridVisible; snapEnabledRef.current = snapEnabled; minimapVisibleRef.current = minimapVisible; canvasRef.current?.requestRenderAll(); }, [gridVisible, snapEnabled, minimapVisible]);

  const brushNames = {
    pen: "Pen", marker: "Marker brush", highlighter: "Freehand highlighter",
    pencil: "Pencil", calligraphy: "Calligraphy",
  };

  return (
    <main className="app">
      <header className="app-header">
        <div>
          <p className="eyebrow">PIXELFORGE · THE SHARED SANCTUM</p>
          <h1>Canvas Engine + Brush Studio</h1>
          <p className="subtitle">Image-backed sticky notes, editable text, custom brushes, and highlighting.</p>
        </div>
        <span className="header-pill">React + Fabric.js</span>
      </header>

      <section className="editor-toolbar">
        <div className="toolbar-section">
          <span className="toolbar-label">Tools</span>
          <div className="toolbar-row">
            <button className={mode === "select" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("select")}>↖ Select</button>
            <button className={mode === "lasso" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("lasso")} title="Draw around objects to select multiple objects and pen strokes">◌ Lasso select</button>
            <button className={mode === "hand" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("hand")}>✋ Hand / Pan</button>
            <button className={mode === "text" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("text")}>T Text</button>
            <button className={mode === "draw" ? "tool-button active" : "tool-button"} onClick={() => { setBrushKind(brushKind === "highlighter" ? "pen" : brushKind); setModeAndRef("draw"); }}>✎ Draw</button>
            <button className={mode === "highlighter" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("highlighter")}>▰ Highlighter</button>
            <button className={mode === "eraser" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("eraser")}>⌫ Eraser</button>
            <button className="tool-button" onClick={() => imageInputRef.current?.click()} disabled={busy} title="Add an image from your computer">＋ Add image</button>
            <input
              ref={imageInputRef}
              className="image-upload-input"
              type="file"
              accept="image/png,image/jpeg,image/webp,image/gif"
              onChange={addImageToCanvas}
              aria-label="Choose an image to add to the canvas"
              tabIndex={-1}
            />
            <select aria-label="Shape type" value={shapeTool} onChange={(e) => { setShapeTool(e.target.value); setModeAndRef("shape"); }} title="Choose a shape, then drag on the canvas">
              {SHAPE_CATEGORIES.map((category) => <optgroup key={category.label} label={category.label}>
                {category.options.map(([value, label]) => <option key={value} value={value}>{label}</option>)}
              </optgroup>)}
              <option value="line">Straight line</option>
            </select>
            <button className={mode === "shape" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("shape")} title="Drag on canvas to draw a custom-sized shape">▱ Draw shape</button>
            <select aria-label="Line style" value={lineTool} onChange={(e) => { setLineTool(e.target.value); curvePointsRef.current = []; setModeAndRef("curve"); setStatus("Click control points. Press Enter to finish, Escape to cancel."); }} title="Choose straight hinged, smooth, or wavy multi-point line">
              <option value="hinged">Hinged line</option><option value="smooth">Smooth curve</option><option value="wavy">Wavy line</option>
            </select>
            <button className={mode === "curve" ? "tool-button active" : "tool-button"} onClick={() => { curvePointsRef.current = []; if (curvePreviewRef.current) canvasRef.current?.remove(curvePreviewRef.current); curvePreviewRef.current = null; setModeAndRef("curve"); setStatus("Click at least 2 control points. Press Enter to finish; Escape cancels."); }}>⌁ Line editor</button>
            <button className="tool-button" onClick={finishCurve} disabled={mode !== "curve"} title="Finish line (Enter)">Finish line ↵</button>
          </div>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Canvas save / restore</span>
          <div className="toolbar-row">
            <button className="tool-button" onClick={exportCanvasJSON}>Export canvas JSON</button>
            <button className="tool-button" onClick={() => canvasImportRef.current?.click()}>Restore from JSON</button>
            <input ref={canvasImportRef} type="file" accept="application/json,.json" onChange={importCanvasJSON} style={{display:"none"}} aria-label="Import canvas JSON file" />
          </div>
          <p className="hint">Exports stable Fabric object metadata to a JSON file. Backend save/restore API calls can be connected once its endpoint contract is agreed.</p>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Revision timeline</span>
          <div className="toolbar-row">
            <select aria-label="Choose canvas revision" value={selectedRevisionId} onChange={(e) => { setSelectedRevisionId(e.target.value); const r = revisions.find((item) => item.id === e.target.value); if (r) compareRevision(r); }}>
              <option value="">Choose a revision…</option>
              {revisions.map((r) => <option key={r.id} value={r.id}>{new Date(r.createdAt).toLocaleString()} · {r.createdBy || "user"}</option>)}
            </select>
            <button className="tool-button" disabled={!selectedRevisionId} onClick={() => compareRevision(revisions.find((r) => r.id === selectedRevisionId))}>Compare</button>
            <button className="tool-button" disabled={!selectedRevisionId} onClick={() => restoreRevision(revisions.find((r) => r.id === selectedRevisionId))}>Restore revision</button>
          </div>
          {revisionCompare && <p className="hint">Selected revision: {revisionCompare.pastCount} objects; current canvas: {revisionCompare.currentCount}. Changed tracked IDs — added: {revisionCompare.added}, removed: {revisionCompare.removed}. Full visual side-by-side diff is not yet provided.</p>}
          {revisions.length === 0 && <p className="hint">Revisions appear after canvas objects are modified. Shared/branching revision storage requires the backend revision contract.</p>}
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Presence & spatial audio</span>
          <div className="toolbar-row">
            <button className="tool-button" onClick={sendLatencyPing}>Measure round-trip latency</button>
            <span className="header-pill">{latencyMs == null ? "Latency: not measured" : `RTT: ${latencyMs.toFixed(1)} ms`}</span>
          </div>
          <p className="hint">Spatial proximity volume is estimated from cursor distance (0–1). WebRTC audio streams/signaling must be connected by the backend teammate; this UI does not claim audio is active.</p>
          {remoteCursors.map((c) => <div className="presence-row" key={c.userId}>
            <span className="presence-dot" style={{background:c.color || "#16a085"}} />
            <span>{c.name || c.userId} · {c.activity || "active"}</span>
            <span className="presence-volume">Proximity volume {Math.round(spatialVolume(c) * 100)}%</span>
          </div>)}
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Collaboration</span>
          <div className="toolbar-row">
            <label className="range-control">Room <input value={roomId} onChange={(e) => setRoomId(e.target.value)} aria-label="Collaboration room ID" style={{width:"150px"}} /></label>
            <label className="range-control">Server <input value={serverUrl} onChange={(e) => setServerUrl(e.target.value)} aria-label="Collaboration server URL" style={{width:"190px"}} /></label>
            <span className="header-pill">● {collabStatus}</span>
          </div>
          <p className="hint">Same room ID + server URL lets collaborators share canvas objects. IndexedDB stores local Yjs changes for offline reconnection. Configure the included Socket.IO server and install dependencies first.</p>
          {remoteCursors.length > 0 && <p className="hint">Collaborators online: {remoteCursors.map((c) => c.name || c.userId).join(", ")}</p>}
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Tables & Graphs</span>
          <div className="toolbar-row">
            <label className="range-control">Rows <input aria-label="Table rows" type="number" min="2" max="12" value={tableRows} onChange={(e) => setTableRows(Number(e.target.value))} style={{width: "64px"}} /></label>
            <label className="range-control">Columns <input aria-label="Table columns" type="number" min="2" max="8" value={tableCols} onChange={(e) => setTableCols(Number(e.target.value))} style={{width: "64px"}} /></label>
            <button className="tool-button" onClick={addTableToCanvas}>＋ Add table</button>
            <select aria-label="Graph type" value={graphType} onChange={(e) => setGraphType(e.target.value)} title="Choose one of ten chart types">
              <option value="bar">Bar chart</option><option value="horizontal-bar">Horizontal bar</option><option value="line">Line chart</option><option value="area">Area chart</option><option value="pie">Pie chart</option><option value="doughnut">Doughnut chart</option><option value="scatter">Scatter plot</option><option value="histogram">Histogram</option><option value="stacked-bar">Stacked bar</option><option value="radar">Radar-style line</option>
            </select>
            <button className="tool-button" onClick={addGraphToCanvas}>＋ Add graph</button>
          </div>
          <div className="toolbar-row">
            <label style={{width: "100%"}}>Graph data (CSV: label,value)
              <textarea value={graphData} onChange={(e) => setGraphData(e.target.value)} rows={3} placeholder={'Label,Value\nA,12\nB,19'} />
            </label>
          </div>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Brush Studio</span>
          <div className="toolbar-row">
            <select aria-label="Brush type" value={brushKind} onChange={(e) => setBrushKind(e.target.value)}>
              <option value="pen">Pen</option>
              <option value="marker">Marker brush</option>
              <option value="pencil">Pencil (rough)</option>
              <option value="calligraphy">Calligraphy</option>
            </select>
            <label className="color-control">Ink <input type="color" value={brushColor} onChange={(e) => setBrushColor(e.target.value)} /></label>
            <label className="range-control">Size {brushWidth}px <input type="range" min="1" max="36" value={brushWidth} onChange={(e) => setBrushWidth(Number(e.target.value))} /></label>
            <label className="range-control">Opacity {Math.round(brushOpacity * 100)}% <input type="range" min="10" max="100" value={Math.round(brushOpacity * 100)} onChange={(e) => setBrushOpacity(Number(e.target.value) / 100)} /></label>
            <label className="check-control"><input type="checkbox" checked={pressureEnabled} onChange={(e) => setPressureEnabled(e.target.checked)} /> Stylus pressure</label>
          </div>
          <div className="toolbar-row">
            <label className="color-control">Highlighter color <input type="color" value={highlighterColor} onChange={(e) => setHighlighterColor(e.target.value)} /></label>
            <label className="range-control">Eraser size {eraserWidth}px <input type="range" min="8" max="60" value={eraserWidth} onChange={(e) => setEraserWidth(Number(e.target.value))} /></label>
            <select aria-label="Eraser mode" value={eraserMode} onChange={(e) => setEraserMode(e.target.value)}>
              <option value="sweep">Sweep eraser</option>
              <option value="whole">Whole-stroke eraser</option>
            </select>
            <button className="tool-button" onClick={highlightSelectedCharacters} title="Select characters while editing text first">Text highlight selection</button>
            <button className="tool-button" onClick={highlightWholeTextObject}>Highlight whole text</button>
          </div>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Object management</span>
          <div className="toolbar-row">
            <label className="line-control">Acting as
              <select aria-label="Demo user identity" value={currentUserId} onChange={(e) => setCurrentUserId(e.target.value)}>
                <option value="user-1">Creator / User 1</option>
                <option value="user-2">Collaborator / User 2</option>
              </select>
            </label>
            <label className="check-control"><input type="checkbox" checked={adminOverride} onChange={(e) => setAdminOverride(e.target.checked)} /> Admin override (demo)</label>
          </div>
          <div className="toolbar-row">
            <button className="tool-button" onClick={groupSelectedObjects} title="Group two or more selected objects">Group selection</button>
            <button className="tool-button" onClick={ungroupSelectedObject} title="Ungroup the selected group">Ungroup</button>
            <button className="tool-button" onClick={() => setSelectedLock(true)} title="Lock selected objects and group components">Lock selection</button>
            <button className="tool-button" onClick={() => setSelectedLock(false)} title="Unlock selected objects and group components">Unlock selection</button>
          </div>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Text formatting</span>
          <div className="toolbar-row">
            <select aria-label="Font family" value={fontFamily} onChange={(e) => { setFontFamily(e.target.value); applyTextStyle({ fontFamily: e.target.value }); }}>
              {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
            <select aria-label="Font size" value={fontSize} onChange={(e) => { setFontSize(Number(e.target.value)); applyTextStyle({ fontSize: Number(e.target.value) }); }}>
              {[12,14,16,18,20,24,28,32,36,42,48,60].map((s) => <option key={s} value={s}>{s}px</option>)}
            </select>
            <button className={bold ? "format-button active" : "format-button"} onClick={() => { const v = !bold; setBold(v); applyTextStyle({ fontWeight: v ? "bold" : "normal" }); }}><b>B</b></button>
            <button className={italic ? "format-button active" : "format-button"} onClick={() => { const v = !italic; setItalic(v); applyTextStyle({ fontStyle: v ? "italic" : "normal" }); }}><i>I</i></button>
            <button className={underline ? "format-button active" : "format-button"} onClick={() => { const v = !underline; setUnderline(v); applyTextStyle({ underline: v }); }}><u>U</u></button>
            <select aria-label="Text alignment" value={textAlign} onChange={(e) => { setTextAlign(e.target.value); applyTextStyle({ textAlign: e.target.value }); }}>
              <option value="left">Left</option><option value="center">Center</option><option value="right">Right</option><option value="justify">Justify</option>
            </select>
            <label className="color-control">Text <input type="color" value={textColor} onChange={(e) => { setTextColor(e.target.value); applyTextStyle({ fill: e.target.value }); }} /></label>
            <label className="color-control">Text BG <input type="color" value={textBackground === "transparent" ? "#FFF4B8" : textBackground} onChange={(e) => { setTextBackground(e.target.value); applyTextStyle({ backgroundColor: e.target.value }); }} /></label>
            <button className="format-button" onClick={() => { setTextBackground("transparent"); applyTextStyle({ backgroundColor: "" }); }}>Clear BG</button>
            <label className="line-control">Line spacing
              <select value={lineSpacing} onChange={(e) => { setLineSpacing(Number(e.target.value)); applyTextStyle({ lineHeight: Number(e.target.value) }); }}>
                {[0.9,1,1.2,1.5,1.8,2].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          </div>
        </div>

      </section>

      <div className="workspace">
        <aside className="designer">
          <section className="panel-section">
            <h2>Sticky-note templates</h2>
            <div className="template-grid">
              {Object.entries(STICKY_TEMPLATES).map(([id, style]) => (
                <button key={id} className={`template-option ${template === id ? "selected" : ""}`} onClick={() => setTemplate(id)} type="button">
                  <img className="template-swatch-image" src={style.image} alt="" draggable="false" />
                  <span className="template-option-name">{style.name}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="panel-section">
            <h2>Sticky-note header</h2>
            <label>Heading text<input value={header} onChange={(e) => setHeader(e.target.value)} /></label>
            <label>Heading font<select value={headerFont} onChange={(e) => setHeaderFont(e.target.value)}>{FONTS.map((f) => <option key={f}>{f}</option>)}</select></label>
            <label>Heading size: {headerSize}px<input type="range" min="14" max="36" value={headerSize} onChange={(e) => setHeaderSize(Number(e.target.value))} /></label>
            <div className="color-row"><label>Heading color</label><input type="color" value={headerColor || selectedTemplate.foreground} onChange={(e) => setHeaderColor(e.target.value)} /></div>
          </section>
          <section className="panel-section">
            <h2>Sticky-note body</h2>
            <label>Body text<textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} /></label>
            <label>Body font<select value={bodyFont} onChange={(e) => setBodyFont(e.target.value)}>{FONTS.map((f) => <option key={f}>{f}</option>)}</select></label>
            <label>Body size: {bodySize}px<input type="range" min="10" max="28" value={bodySize} onChange={(e) => setBodySize(Number(e.target.value))} /></label>
            <div className="color-row"><label>Body color</label><input type="color" value={bodyColor || selectedTemplate.foreground} onChange={(e) => setBodyColor(e.target.value)} /></div>
          </section>
          <section className="panel-section">
            <h2>Note dimensions</h2>
            <label>Width: {noteWidth}px<input type="range" min="220" max="360" step="10" value={noteWidth} onChange={(e) => setNoteWidth(Number(e.target.value))} /></label>
            <label>Height: {noteHeight}px<input type="range" min="160" max="300" step="10" value={noteHeight} onChange={(e) => setNoteHeight(Number(e.target.value))} /></label>
            <div className="preview-stage">
              <div className="note-preview" style={{ width: `${Math.min(noteWidth,300)}px`, height: `${Math.min(noteHeight,240)}px`, backgroundImage: `url("${selectedTemplate.image}")` }}>
                <div className="preview-header" style={{ fontFamily: headerFont, fontSize: `${headerSize}px`, color: headerColor || selectedTemplate.foreground }}>{header || "Title"}</div>
                <div className="preview-body" style={{ fontFamily: bodyFont, fontSize: `${bodySize}px`, color: bodyColor || selectedTemplate.foreground }}>{body || "Write something..."}</div>
              </div>
            </div>
            <button className="primary-button" onClick={addDesignedStickyNote} disabled={busy}>{busy ? "Loading image..." : "+ Add Sticky Note"}</button>
            <button className="secondary-button" onClick={clearCanvas}>Clear Canvas</button>
          </section>
          <p className="status-message" role="status">{status}</p>
        </aside>

        <section className="canvas-panel">
          <div className="canvas-heading">
            <div>
              <h2>Your canvas</h2>
              <p>{mode === "hand" ? "Drag to move around the canvas. You can also hold Space and drag." : mode === "text" ? "Click an empty spot to create text." : mode === "draw" ? `Draw with ${brushNames[brushKind] || "your brush"}.` : mode === "highlighter" ? "Draw translucent strokes over any canvas content." : mode === "eraser" ? (eraserMode === "sweep" ? "Sweep over strokes to erase them." : "Click a stroke to remove the whole stroke.") : mode === "lasso" ? "Drag a freeform loop around object centers to select multiple objects and pen strokes." : "Select, move, resize, rotate and layer objects. Arrow keys nudge the selection; Shift + arrows move 10 world units. Double-click standalone text to edit."}</p>
            </div>
            <div className="canvas-nav-controls">
              <button className="tool-button" onClick={() => zoomBy(1.2)} aria-label="Zoom in">＋</button>
              <span className="zoom-readout">{zoomPercent}%</span>
              <button className="tool-button" onClick={() => zoomBy(1 / 1.2)} aria-label="Zoom out">−</button>
              <button className="tool-button" onClick={resetView}>Reset view</button>
              <button className={gridVisible ? "tool-button active" : "tool-button"} onClick={() => setGridVisible((v) => !v)}>Grid {gridVisible ? "On" : "Off"}</button>
              <button className={snapEnabled ? "tool-button active" : "tool-button"} onClick={() => setSnapEnabled((v) => !v)}>Snap {snapEnabled ? "On" : "Off"}</button>
              <button className={minimapVisible ? "tool-button active" : "tool-button"} onClick={() => setMinimapVisible((v) => !v)}>Minimap {minimapVisible ? "On" : "Off"}</button>
              <span className="canvas-tag">{selectedObject ? (selectedObject.isPixelForgeText ? "Text selected" : selectedObject.isPixelForgeStroke ? "Stroke selected" : "Object selected") : "No selection"}</span>
            </div>
          </div>
          <div className="canvas-frame"><canvas ref={canvasElement} />
            <div className="remote-cursor-layer" aria-label="Collaborator cursors">
              {remoteCursors.map((c) => <div key={c.userId} className="remote-cursor" style={{left:c.x,top:c.y,"--cursor-color":c.color || "#16a085"}}>
                <span className="remote-cursor-arrow">➤</span><span className="remote-cursor-label">{c.name || c.userId} · {c.activity || "active"}</span>
              </div>)}
            </div>
            {selectedObject && floatingToolbarPosition && mode === "select" && !selectedObject.isEditing && <div className="floating-object-toolbar" style={{ left: floatingToolbarPosition.left, top: floatingToolbarPosition.top }} onMouseDown={(event) => event.stopPropagation()}>
              <button className="tool-button" onClick={undo} disabled={!canUndo} title="Undo">↶ Undo</button>
              <button className="tool-button" onClick={redo} disabled={!canRedo} title="Redo">↷ Redo</button>
              <button className="tool-button" onClick={duplicateSelectedObject}>Duplicate</button>
              <button className="tool-button" onClick={() => moveSelectedLayer("front")}>Bring to front</button>
              <button className="tool-button" onClick={() => moveSelectedLayer("back")}>Send to back</button>
              <button className="tool-button danger" onClick={deleteSelectedObject}>Delete</button>
            </div>}
            {minimapVisible && <div className="minimap-wrap"><span>MINIMAP</span><canvas ref={minimapElement} width="190" height="130" onClick={navigateFromMinimap} aria-label="Canvas minimap; click to navigate" /></div>}
          </div>
          <p className="hint">Select multiple objects with Shift-click or drag a selection box. Choose from the shape catalogue, then drag to size. In Line editor, click control points and press Enter to finish or Escape to cancel. Drag handles to resize or rotate. Arrow keys nudge selected objects (Shift + arrow = 10 world units). Ctrl/Cmd + D duplicates; Delete removes. Use Bring to front / Send to back to change layer order. Use Lasso select to draw around objects/strokes; use Object management to group, ungroup, lock, or unlock selections. Creator/admin lock permissions still require authenticated backend enforcement. Collaboration sync uses per-object Yjs entries; do not expose this demo server to the public internet without authentication and authorization. Text formatting currently applies to standalone canvas text; sticky-note header/body formatting still needs to be connected to the canvas selection.</p>
        </section>
      </div>
    </main>
  );
}
