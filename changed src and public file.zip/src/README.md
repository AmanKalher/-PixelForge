# PixelForge collaboration starter

## Frontend dependencies
Run in your existing Vite frontend folder:

```bash
npm install yjs y-indexeddb socket.io-client
```

The existing project dependencies (React, Vite, Fabric.js) remain required.

## Relay dependencies
This starter server is a separate Node.js process:

```bash
npm install socket.io
```

If the frontend and server are in the same package, install `socket.io` there too.
Run the relay with a Node version that supports ES modules:

```bash
node server.js
```

By default the frontend connects to `http://localhost:3001` and room `pixelforge-demo`.
For another machine, set the Server field to the host computer's reachable URL and
configure `CLIENT_ORIGIN` to your frontend origin.

## Included
- Yjs document and a per-object Y.Map so concurrent edits to different objects do not
  overwrite one whole-canvas snapshot.
- Socket.IO update relay and live cursor metadata.
- IndexedDB persistence for offline Yjs updates, which sync after reconnect.
- Canvas snapshots stored in a Y.Array when objects are modified.

## Important limitations before production
- The relay is a development transport, not an authenticated collaboration backend.
  Do not expose it publicly without login/session validation, room access checks, rate
  limiting, and persistence.
- Object entries are currently serialized on `object:added` and `object:modified`.
  Collaborative text editing may need throttled `text:changed` handling for character-
  by-character live updates.
- Version snapshots are stored in the Yjs document, but a version browser/restore UI
  and durable server-side version archive still need to be wired.
- Cursor payloads are relayed, but this starter only reports online collaborator names;
  it does not yet draw remote cursor overlays on the canvas.
- Existing object-lock and host approval rules must be enforced by the backend before
  accepting changes. Frontend flags are not a security boundary.
- Test grouped objects, images, sticky notes, tables, graphs, and shapes in your installed
  Fabric.js version before merging. No production build has been run here.
