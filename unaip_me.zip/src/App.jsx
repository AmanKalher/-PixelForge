import { useCallback, useEffect, useRef, useState } from "react";
import {
  Canvas,
  FabricImage,
  IText,
  PencilBrush,
  Point,
  Textbox,
} from "fabric";
import { STICKY_TEMPLATES, createStickyNote } from "./stickyNoteTemplates";
import { clampZoom, getWorldPointer, getZoomLevel } from "./canvasCoordinates";
import "./App.css";

const W = 1000;
const H = 680;
const BG = "#F8FAFC";
const FONTS = ["Arial", "Georgia", "Verdana", "Trebuchet MS", "Courier New", "Times New Roman"];
const EXTRA_PROPS = [
  "stickyNoteData", "stickyPart", "isPixelForgeText", "isPixelForgeStroke",
  "pixelForgeObjectType", "brushKind", "brushColor", "brushWidth",
  "brushOpacity", "pressureEnabled",
];
function colorWithAlpha(color, alpha) {
  const hex = String(color || "#FDE047").replace("#", "");
  const normalized = hex.length === 3
    ? hex.split("").map((char) => char + char).join("")
    : hex;
  if (!/^[0-9a-fA-F]{6}$/.test(normalized)) {
    return `rgba(253, 224, 71, ${alpha})`;
  }
  const red = parseInt(normalized.slice(0, 2), 16);
  const green = parseInt(normalized.slice(2, 4), 16);
  const blue = parseInt(normalized.slice(4, 6), 16);
  return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
}


class PressurePencilBrush extends PencilBrush {
  constructor(canvas, kind, settings) {
    super(canvas);
    this.kind = kind;
    this.settings = settings;
    this.baseWidth = settings.width;
    this.color = settings.color;
    this.width = settings.width;
    this.strokeLineCap = kind === "calligraphy" ? "square" : "round";
    this.strokeLineJoin = "round";
    this.strokeDashArray = kind === "pencil" ? [1, 1.8] : null;
  }

  _pressureWidth(event) {
    const s = this.settings;
    const p = event && typeof event.pressure === "number" && event.pressure > 0
      ? event.pressure
      : 0.5;
    if (!s.pressureEnabled || !event || typeof event.pressure !== "number" || event.pressure <= 0) {
      return s.width;
    }
    return Math.max(1, s.width * (0.35 + p * 1.3));
  }

  onMouseDown(pointer, event) {
    this.settings.width = this.settings.width || 4;
    this.width = this._pressureWidth(event);
    this.color = this.settings.color;
    this.opacity = this.settings.opacity;
    this.strokeDashArray = this.kind === "pencil" ? [1, 1.8] : null;
    super.onMouseDown(pointer, event);
  }

  onMouseMove(pointer, event) {
    this.width = this._pressureWidth(event);
    this.color = this.settings.color;
    super.onMouseMove(pointer, event);
  }

_setBrushStyles(ctx) {
  super._setBrushStyles(ctx);

  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  if (this.kind === "highlighter") {
    ctx.globalAlpha = 0.30;
  } else {
    ctx.globalAlpha = this.settings.opacity;
  }
}
}

function makeBrush(canvas, kind, settings) {
  const brush = new PressurePencilBrush(canvas, kind, settings);
  brush.width = settings.width;
  brush.color = settings.color;
  return brush;
}

export default function App() {
  const canvasElement = useRef(null);
  const canvasRef = useRef(null);
  const minimapElement = useRef(null);
  const [gridVisible, setGridVisible] = useState(true);
  const [snapEnabled, setSnapEnabled] = useState(false);
  const [minimapVisible, setMinimapVisible] = useState(true);
  const gridVisibleRef = useRef(true);
  const snapEnabledRef = useRef(false);
  const minimapVisibleRef = useRef(true);
  const modeRef = useRef("select");
  const brushSettingsRef = useRef({
    kind: "pen", color: "#252525", width: 4, opacity: 1, pressureEnabled: true,
  });
  const textSettingsRef = useRef({
    fontFamily: "Arial", fontSize: 24, textColor: "#252525", bold: false,
    italic: false, underline: false, textAlign: "left",
    textBackground: "transparent", lineSpacing: 1.2,
  });
  const historyRef = useRef({ undo: [], redo: [], restoring: false });
  const historyTimer = useRef(null);
  const eraserRef = useRef({ active: false, lastPoint: null });
  const panRef = useRef({ active: false, lastX: 0, lastY: 0 });
  const spaceDownRef = useRef(false);
  const [zoomPercent, setZoomPercent] = useState(100);

  const [mode, setMode] = useState("select");
  const [selectedObject, setSelectedObject] = useState(null);
  const [floatingToolbarPosition, setFloatingToolbarPosition] = useState(null);
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [status, setStatus] = useState("Choose a tool to begin.");

  const [brushKind, setBrushKind] = useState("pen");
  const [brushColor, setBrushColor] = useState("#252525");
  const [brushWidth, setBrushWidth] = useState(4);
  const [brushOpacity, setBrushOpacity] = useState(1);
  const [pressureEnabled, setPressureEnabled] = useState(true);
  const [eraserMode, setEraserMode] = useState("sweep");
  const [eraserWidth, setEraserWidth] = useState(22);
  const [highlighterColor, setHighlighterColor] = useState("#FDE047");

  // Existing sticky-note designer state.
  const [template, setTemplate] = useState("sunny");
  const [header, setHeader] = useState("Title");
  const [body, setBody] = useState("Write something...");
  const [headerFont, setHeaderFont] = useState("Georgia");
  const [bodyFont, setBodyFont] = useState("Arial");
  const [headerSize, setHeaderSize] = useState(25);
  const [bodySize, setBodySize] = useState(17);
  const [headerColor, setHeaderColor] = useState("");
  const [bodyColor, setBodyColor] = useState("");
  const [noteWidth, setNoteWidth] = useState(280);
  const [noteHeight, setNoteHeight] = useState(200);
  const [busy, setBusy] = useState(false);

  // Standalone text formatting state.
  const [fontFamily, setFontFamily] = useState("Arial");
  const [fontSize, setFontSize] = useState(24);
  const [textColor, setTextColor] = useState("#252525");
  const [bold, setBold] = useState(false);
  const [italic, setItalic] = useState(false);
  const [underline, setUnderline] = useState(false);
  const [textAlign, setTextAlign] = useState("left");
  const [textBackground, setTextBackground] = useState("transparent");
  const [lineSpacing, setLineSpacing] = useState(1.2);

  const selectedTemplate = STICKY_TEMPLATES[template];

  const syncHistoryButtons = useCallback(() => {
    setCanUndo(historyRef.current.undo.length > 1);
    setCanRedo(historyRef.current.redo.length > 0);
  }, []);

  const saveHistory = useCallback(() => {
    const canvas = canvasRef.current;
    const hist = historyRef.current;
    if (!canvas || hist.restoring) return;
    window.clearTimeout(historyTimer.current);
    historyTimer.current = window.setTimeout(() => {
      const c = canvasRef.current;
      if (!c || hist.restoring) return;
      const json = JSON.stringify(c.toJSON(EXTRA_PROPS));
      if (hist.undo[hist.undo.length - 1] !== json) {
        hist.undo.push(json);
        if (hist.undo.length > 80) hist.undo.shift();
        hist.redo = [];
        syncHistoryButtons();
      }
    }, 100);
  }, [syncHistoryButtons]);

  const updateFloatingToolbar = useCallback((obj) => {
    const canvas = canvasRef.current;
    if (!canvas || !obj || modeRef.current !== "select" || obj.isEditing) {
      setFloatingToolbarPosition(null);
      return;
    }
    const bounds = obj.getBoundingRect();
    const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
    const zoom = canvas.getZoom() || 1;
    // Fabric's bounding rectangle is in scene/world coordinates. Convert it
    // through the viewport transform to position the HTML toolbar on screen.
    const left = bounds.left * zoom + vpt[4];
    const top = bounds.top * zoom + vpt[5];
    const frame = canvas.wrapperEl?.parentElement;
    const frameRect = frame?.getBoundingClientRect();
    const canvasRect = canvas.upperCanvasEl?.getBoundingClientRect();
    if (!frameRect || !canvasRect) return;
    const scaleX = canvasRect.width / (canvas.getWidth() || 1);
    const scaleY = canvasRect.height / (canvas.getHeight() || 1);
    const localLeft = (left * scaleX) + (canvasRect.left - frameRect.left);
    const localTop = (top * scaleY) + (canvasRect.top - frameRect.top);
    const toolbarWidth = 430;
    const x = Math.max(8, Math.min(localLeft + bounds.width * zoom * scaleX / 2 - toolbarWidth / 2, frameRect.width - toolbarWidth - 8));
    const y = Math.max(8, localTop - 48);
    setFloatingToolbarPosition({ left: x, top: y });
  }, []);

  const updateSelected = useCallback((obj) => {
    setSelectedObject(obj || null);
    updateFloatingToolbar(obj || null);
    if (!obj || !obj.isPixelForgeText) return;
    setFontFamily(obj.fontFamily || "Arial");
    setFontSize(obj.fontSize || 24);
    setTextColor(typeof obj.fill === "string" ? obj.fill : "#252525");
    setBold(obj.fontWeight === "bold");
    setItalic(obj.fontStyle === "italic");
    setUnderline(Boolean(obj.underline));
    setTextAlign(obj.textAlign || "left");
    setTextBackground(obj.backgroundColor || "transparent");
    setLineSpacing(Number(obj.lineHeight) || 1.2);
  }, [updateFloatingToolbar]);

  const installBrush = useCallback((canvas, kind, settings) => {
    const actualKind = kind === "highlighter" ? "highlighter" : kind;
    const adjusted = {
      ...settings,
      color: actualKind === "highlighter" ? settings.color : settings.color,
      opacity: actualKind === "highlighter" ? Math.min(settings.opacity, 0.32) : settings.opacity,
      width: actualKind === "highlighter" ? Math.max(settings.width, 18) : settings.width,
    };
    const brush = makeBrush(canvas, actualKind, adjusted);
    if (actualKind === "highlighter") {
      // PencilBrush uses the color as the stroke; alpha is set in _setBrushStyles.
      brush.width = Math.max(settings.width, 18);
    }
    canvas.freeDrawingBrush = brush;
  }, []);

  const drawGrid = useCallback((canvas) => {
    if (!canvas || !gridVisibleRef.current) return;
    const ctx = canvas.getContext();
    const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
    const zoom = Math.max(0.01, vpt[0] || 1);
    const step = 25;
    const width = canvas.getWidth();
    const height = canvas.getHeight();
    const worldLeft = -vpt[4] / zoom;
    const worldTop = -vpt[5] / zoom;
    const startX = ((worldLeft % step) + step) % step;
    const startY = ((worldTop % step) + step) % step;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.strokeStyle = "rgba(112, 125, 151, 0.16)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = (step - startX) * zoom; x < width; x += step * zoom) {
      const crispX = Math.round(x) + 0.5;
      ctx.moveTo(crispX, 0); ctx.lineTo(crispX, height);
    }
    for (let y = (step - startY) * zoom; y < height; y += step * zoom) {
      const crispY = Math.round(y) + 0.5;
      ctx.moveTo(0, crispY); ctx.lineTo(width, crispY);
    }
    ctx.stroke();
    ctx.restore();
  }, []);

  const drawMinimap = useCallback(() => {
    const canvas = canvasRef.current;
    const mini = minimapElement.current;
    if (!canvas || !mini || !minimapVisibleRef.current) return;
    const ctx = mini.getContext("2d");
    const w = mini.width, h = mini.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "#f8fafc"; ctx.fillRect(0, 0, w, h);
    const objects = canvas.getObjects().filter((o) => !o.isGridHelper);
    const bounds = objects.map((o) => o.getBoundingRect()).filter((b) => Number.isFinite(b.left) && Number.isFinite(b.top));
    const vpt = canvas.viewportTransform || [1, 0, 0, 1, 0, 0];
    const zoom = Math.max(0.01, vpt[0] || 1);
    const view = { left: -vpt[4] / zoom, top: -vpt[5] / zoom, width: canvas.getWidth() / zoom, height: canvas.getHeight() / zoom };
    let minX = Math.min(view.left, ...bounds.map((b) => b.left), -100);
    let minY = Math.min(view.top, ...bounds.map((b) => b.top), -100);
    let maxX = Math.max(view.left + view.width, ...bounds.map((b) => b.left + b.width), 100);
    let maxY = Math.max(view.top + view.height, ...bounds.map((b) => b.top + b.height), 100);
    const pad = 30; minX -= pad; minY -= pad; maxX += pad; maxY += pad;
    const scale = Math.min((w - 12) / (maxX - minX), (h - 12) / (maxY - minY));
    const ox = (w - (maxX - minX) * scale) / 2;
    const oy = (h - (maxY - minY) * scale) / 2;
    ctx.fillStyle = "#b8c2d3";
    bounds.forEach((b) => ctx.fillRect(ox + (b.left - minX) * scale, oy + (b.top - minY) * scale, Math.max(2, b.width * scale), Math.max(2, b.height * scale)));
    ctx.strokeStyle = "#655bf2"; ctx.lineWidth = 1.5;
    ctx.strokeRect(ox + (view.left - minX) * scale, oy + (view.top - minY) * scale, Math.max(3, view.width * scale), Math.max(3, view.height * scale));
    mini.dataset.minX = String(minX); mini.dataset.minY = String(minY); mini.dataset.scale = String(scale); mini.dataset.offsetX = String(ox); mini.dataset.offsetY = String(oy);
  }, []);

  function navigateFromMinimap(event) {
    const canvas = canvasRef.current, mini = minimapElement.current;
    if (!canvas || !mini) return;
    const rect = mini.getBoundingClientRect();
    const px = (event.clientX - rect.left) * (mini.width / rect.width);
    const py = (event.clientY - rect.top) * (mini.height / rect.height);
    const scale = Number(mini.dataset.scale), minX = Number(mini.dataset.minX), minY = Number(mini.dataset.minY);
    const ox = Number(mini.dataset.offsetX), oy = Number(mini.dataset.offsetY);
    if (!scale) return;
    const worldX = (px - ox) / scale + minX, worldY = (py - oy) / scale + minY;
    const zoom = getZoomLevel(canvas), vpt = canvas.viewportTransform;
    vpt[4] = canvas.getWidth() / 2 - worldX * zoom;
    vpt[5] = canvas.getHeight() / 2 - worldY * zoom;
    canvas.setViewportTransform(vpt); canvas.requestRenderAll();
    setZoomPercent(Math.round(zoom * 100));
  }

  useEffect(() => {
    const canvas = new Canvas(canvasElement.current, {
      width: W,
      height: H,
      backgroundColor: "rgba(0, 0, 0, 0)",
      preserveObjectStacking: true,
      selection: true,
      enablePointerEvents: true,
    });
    canvasRef.current = canvas;
    installBrush(canvas, "pen", brushSettingsRef.current);

    const onSelection = (e) => updateSelected(e.selected?.[0] || canvas.getActiveObject());
    const onClearSelection = () => updateSelected(null);
    const onModified = () => {
      updateSelected(canvas.getActiveObject());
      saveHistory();
    };
    const onPathCreated = (e) => {
      if (!e.path) return;
      const s = brushSettingsRef.current;
      e.path.isPixelForgeStroke = true;
      e.path.pixelForgeObjectType = "stroke";
      e.path.brushKind = modeRef.current === "draw" ? s.kind : "highlighter";
      e.path.brushColor = s.color;
      e.path.brushWidth = s.width;
      e.path.brushOpacity = s.opacity;
      e.path.pressureEnabled = s.pressureEnabled;

      // Fabric turns the live brush stroke into a Path after pointer-up.
      // Canvas globalAlpha only affects the live preview, so save alpha in
      // the actual path stroke color as rgba() as well.
      if (modeRef.current === "highlighter") {
        e.path.set({
          stroke: colorWithAlpha(s.color, 0.30),
          opacity: 1,
          objectCaching: false,
        });
        e.path.dirty = true;
      }

      e.path.selectable = true;
      e.path.evented = true;
      saveHistory();
    };

    const eraseWholeStrokeAt = (point) => {
      const objects = canvas.getObjects().slice().reverse();
      const target = objects.find((obj) =>
        obj.isPixelForgeStroke &&
        obj.containsPoint(point)
      );
      if (target) {
        canvas.remove(target);
        canvas.requestRenderAll();
        setStatus("Whole stroke erased.");
        saveHistory();
      }
    };

    const eraseSweepAt = (point) => {
      const radius = eraserWidth;
      const objects = canvas.getObjects().slice().reverse();
      const targets = objects.filter((obj) => {
        if (!obj.isPixelForgeStroke) return false;
        const center = obj.getCenterPoint();
        const bounds = obj.getBoundingRect();
        const nearestX = Math.max(bounds.left, Math.min(point.x, bounds.left + bounds.width));
        const nearestY = Math.max(bounds.top, Math.min(point.y, bounds.top + bounds.height));
        const dx = point.x - nearestX;
        const dy = point.y - nearestY;
        const nearBounds = dx * dx + dy * dy <= radius * radius;
        const centerNear = Math.hypot(center.x - point.x, center.y - point.y) <= radius + Math.max(bounds.width, bounds.height) / 2;
        return nearBounds || centerNear;
      });
      if (targets.length) {
        targets.forEach((obj) => canvas.remove(obj));
        canvas.requestRenderAll();
        saveHistory();
      }
    };

    const onMouseDown = (event) => {
      const currentMode = modeRef.current;
      const target = event.target;
      const point = getWorldPointer(canvas, event.e);

      // Pan changes only the viewport transform; canvas objects keep their world coordinates.
      if (currentMode === "hand" || spaceDownRef.current) {
        panRef.current = {
          active: true,
          lastX: event.e.clientX,
          lastY: event.e.clientY,
        };
        canvas.discardActiveObject();
        canvas.selection = false;
        canvas.defaultCursor = "grabbing";
        canvas.requestRenderAll();
        event.e.preventDefault?.();
        return;
      }

      if (currentMode === "eraser") {
        if (eraserMode === "whole") {
          eraseWholeStrokeAt(point);
        } else {
          eraserRef.current.active = true;
          eraserRef.current.lastPoint = point;
          eraseSweepAt(point);
        }
        return;
      }

      if (currentMode !== "text" || target) return;

      const settings = textSettingsRef.current;
      const text = new Textbox("Type something...", {
        left: point.x,
        top: point.y,
        width: 260,
        fontFamily: settings.fontFamily,
        fontSize: settings.fontSize,
        fill: settings.textColor,
        fontWeight: settings.bold ? "bold" : "normal",
        fontStyle: settings.italic ? "italic" : "normal",
        underline: settings.underline,
        textAlign: settings.textAlign,
        backgroundColor: settings.textBackground === "transparent" ? "" : settings.textBackground,
        lineHeight: Number(settings.lineSpacing),
        editable: true,
        splitByGrapheme: true,
        objectCaching: false,
        padding: 3,
      });
      text.isPixelForgeText = true;
      text.pixelForgeObjectType = "text";
      canvas.add(text);
      canvas.setActiveObject(text);
      text.enterEditing();
      text.selectAll();
      canvas.requestRenderAll();
      setModeAndRef("select");
      setStatus("Text created. Type to replace the placeholder.");
      saveHistory();
    };

    const onMouseMove = (event) => {
      if (panRef.current.active) {
        const dx = event.e.clientX - panRef.current.lastX;
        const dy = event.e.clientY - panRef.current.lastY;
        const vpt = canvas.viewportTransform;
        vpt[4] += dx;
        vpt[5] += dy;
        panRef.current.lastX = event.e.clientX;
        panRef.current.lastY = event.e.clientY;
        canvas.setViewportTransform(vpt);
        canvas.requestRenderAll();
        updateFloatingToolbar(canvas.getActiveObject());
        return;
      }
      if (modeRef.current !== "eraser" || eraserMode !== "sweep" || !eraserRef.current.active) return;
      const point = getWorldPointer(canvas, event.e);
      const last = eraserRef.current.lastPoint;
      const steps = last ? Math.max(1, Math.ceil(Math.hypot(point.x - last.x, point.y - last.y) / Math.max(4, eraserWidth / 2))) : 1;
      for (let i = 1; i <= steps; i++) {
        const p = last
          ? { x: last.x + (point.x - last.x) * i / steps, y: last.y + (point.y - last.y) * i / steps }
          : point;
        eraseSweepAt(p);
      }
      eraserRef.current.lastPoint = point;
    };
    const onMouseUp = () => {
      panRef.current.active = false;
      eraserRef.current.active = false;
      eraserRef.current.lastPoint = null;
      if (modeRef.current === "hand") canvas.defaultCursor = "grab";
      else if (!spaceDownRef.current) canvas.defaultCursor = modeRef.current === "text" ? "text" : modeRef.current === "draw" || modeRef.current === "highlighter" ? "crosshair" : modeRef.current === "eraser" ? "cell" : "default";
      canvas.selection = modeRef.current === "select" || modeRef.current === "text";
    };

    const onMouseWheel = (event) => {
      const e = event.e;
      let zoom = getZoomLevel(canvas);
      zoom = clampZoom(zoom * Math.pow(0.999, e.deltaY));
      canvas.zoomToPoint(new Point(e.offsetX, e.offsetY), zoom);
      setZoomPercent(Math.round(zoom * 100));
      updateFloatingToolbar(canvas.getActiveObject());
      e.preventDefault();
      e.stopPropagation();
    };

    const onDoubleClick = (event) => {
      const target = event.target;
      if (target?.isPixelForgeText && typeof target.enterEditing === "function") {
        canvas.setActiveObject(target);
        target.enterEditing();
        target.selectAll();
        canvas.requestRenderAll();
      }
    };

    canvas.on("selection:created", onSelection);
    canvas.on("selection:updated", onSelection);
    canvas.on("selection:cleared", onClearSelection);
    canvas.on("object:modified", onModified);
    const onObjectMoving = (event) => {
      const obj = event.target;
      if (!obj) return;
      if (snapEnabledRef.current) {
        const grid = 25;
        obj.set({ left: Math.round((obj.left || 0) / grid) * grid, top: Math.round((obj.top || 0) / grid) * grid });
        obj.setCoords();
      }
      updateFloatingToolbar(obj);
    };
    const onBeforeRender = () => drawGrid(canvas);
    const onAfterRender = () => drawMinimap();
    canvas.on("object:moving", onObjectMoving);
    canvas.on("before:render", onBeforeRender);
    canvas.on("after:render", onAfterRender);
    canvas.on("path:created", onPathCreated);
    canvas.on("mouse:down", onMouseDown);
    canvas.on("mouse:move", onMouseMove);
    canvas.on("mouse:up", onMouseUp);
    canvas.on("mouse:wheel", onMouseWheel);
    canvas.on("mouse:dblclick", onDoubleClick);

    historyRef.current.undo = [JSON.stringify(canvas.toJSON(EXTRA_PROPS))];
    syncHistoryButtons();

    return () => {
      window.clearTimeout(historyTimer.current);
      canvas.off("object:moving", onObjectMoving);
      canvas.off("before:render", onBeforeRender);
      canvas.off("after:render", onAfterRender);
      canvas.dispose();
      canvasRef.current = null;
    };
    // Canvas is intentionally initialized once; callbacks read current values from refs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Current settings are copied to refs each render so the Fabric listeners stay fresh.
  textSettingsRef.current = {
    fontFamily, fontSize, textColor, bold, italic, underline, textAlign,
    textBackground, lineSpacing,
  };
 brushSettingsRef.current = {
  kind: brushKind,
  color: mode === "highlighter" ? highlighterColor : brushColor,
  width: mode === "highlighter"
    ? Math.max(brushWidth, 18)
    : brushWidth,
  opacity: mode === "highlighter"
    ? 0.30
    : brushOpacity,
  pressureEnabled,
};

  // Keep the Fabric brush in sync with the active brush selection.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (mode === "draw" || mode === "highlighter") {
      installBrush(canvas, mode === "highlighter" ? "highlighter" : brushKind, brushSettingsRef.current);
      canvas.isDrawingMode = true;
    } else {
      canvas.isDrawingMode = false;
    }
    canvas.requestRenderAll();
  }, [mode, brushKind, brushColor, brushWidth, brushOpacity, highlighterColor, pressureEnabled, installBrush]);

  function setModeAndRef(next) {
    modeRef.current = next;
    setMode(next);
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.isDrawingMode = next === "draw" || next === "highlighter";
    canvas.selection = next === "select" || next === "text";
    canvas.defaultCursor =
      next === "hand" ? "grab" :
      next === "text" ? "text" :
      next === "draw" || next === "highlighter" ? "crosshair" :
      next === "eraser" ? "cell" : "default";

    canvas.getObjects().forEach((obj) => {
      if (next === "draw" || next === "highlighter" || next === "eraser" || next === "hand") {
        obj.selectable = false;
        obj.evented = false;
      } else {
        obj.selectable = true;
        obj.evented = true;
      }
    });
    canvas.requestRenderAll();
  }

  function applyTextStyle(patch) {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active || !active.isPixelForgeText) {
      setStatus("Select standalone canvas text to format it. Sticky-note header/body styling remains in the designer.");
      return;
    }
    active.set(patch);
    active.setCoords();
    canvas.requestRenderAll();
    updateSelected(active);
    saveHistory();
  }

  function changeFontFamily(v) { setFontFamily(v); applyTextStyle({ fontFamily: v }); }
  function changeFontSize(v) { setFontSize(Number(v)); applyTextStyle({ fontSize: Number(v) }); }
  function changeTextColor(v) { setTextColor(v); applyTextStyle({ fill: v }); }
  function changeBold() { const v = !bold; setBold(v); applyTextStyle({ fontWeight: v ? "bold" : "normal" }); }
  function changeItalic() { const v = !italic; setItalic(v); applyTextStyle({ fontStyle: v ? "italic" : "normal" }); }
  function changeUnderline() { const v = !underline; setUnderline(v); applyTextStyle({ underline: v }); }
  function changeAlign(v) { setTextAlign(v); applyTextStyle({ textAlign: v }); }
  function changeTextBackground(v) { setTextBackground(v); applyTextStyle({ backgroundColor: v === "transparent" ? "" : v }); }
  function changeLineSpacing(v) { setLineSpacing(Number(v)); applyTextStyle({ lineHeight: Number(v) }); }

  function highlightSelectedCharacters(color = highlighterColor) {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!active || !active.isPixelForgeText || !active.isEditing) {
      setStatus("To highlight selected characters, double-click standalone text, select characters, then choose Text Highlight.");
      return;
    }
    const start = active.selectionStart;
    const end = active.selectionEnd;
    if (start === end) {
      setStatus("Select one or more characters inside the text before highlighting.");
      return;
    }
    // Fabric.js IText/Textbox styles are indexed by line and character.
    const lines = active.text.split(/\r?\n/);
    const styles = { ...(active.styles || {}) };
    let globalIndex = 0;
    lines.forEach((line, lineIndex) => {
      const lineStyles = { ...(styles[lineIndex] || {}) };
      for (let charIndex = 0; charIndex < line.length; charIndex++) {
        if (globalIndex >= start && globalIndex < end) {
          lineStyles[charIndex] = { ...(lineStyles[charIndex] || {}), textBackgroundColor: color };
        }
        globalIndex++;
      }
      styles[lineIndex] = lineStyles;
      if (lineIndex < lines.length - 1) globalIndex++;
    });
    active.set("styles", styles);
    active.initDimensions();
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Selected characters highlighted.");
  }

  function highlightWholeTextObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!active || !active.isPixelForgeText) {
      setStatus("Select a standalone text object first.");
      return;
    }
    active.set("backgroundColor", highlighterColor);
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Whole text object highlighted.");
  }

  async function addDesignedStickyNote() {
    const canvas = canvasRef.current;
    if (!canvas || busy) return;
    setBusy(true);
    try {
      const note = await createStickyNote({
        template, header: header || "Title", body: body || "Write something...",
        left: 35 + Math.random() * 100, top: 35 + Math.random() * 80,
        width: noteWidth, height: noteHeight, headerFont, bodyFont,
        headerSize, bodySize,
        headerColor: headerColor || selectedTemplate.foreground,
        bodyColor: bodyColor || selectedTemplate.foreground,
      });
      canvas.add(note);
      canvas.setActiveObject(note);
      canvas.requestRenderAll();
      saveHistory();
      setStatus(`${selectedTemplate.name} added to canvas.`);
    } catch (error) {
      console.error(error);
      setStatus("Could not load note image. Check public/sticky-notes.");
    } finally {
      setBusy(false);
    }
  }

  function deleteSelectedObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) {
      setStatus("Select an object first.");
      return;
    }
    canvas.remove(active);
    canvas.discardActiveObject();
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Selected object deleted.");
  }

  async function duplicateSelectedObject() {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) {
      setStatus("Select an object to duplicate.");
      return;
    }
    try {
      const clone = await active.clone(EXTRA_PROPS);
      clone.set({ left: (active.left || 0) + 24, top: (active.top || 0) + 24 });
      canvas.add(clone);
      canvas.setActiveObject(clone);
      canvas.requestRenderAll();
      saveHistory();
      setStatus("Object duplicated.");
    } catch (error) {
      console.error(error);
      setStatus("Could not duplicate this object.");
    }
  }

  function getSelectedObjects() {
    const canvas = canvasRef.current;
    if (!canvas) return [];
    const objects = canvas.getActiveObjects();
    return objects.length ? objects : [];
  }

  function moveSelectedLayer(direction) {
    const canvas = canvasRef.current;
    const objects = getSelectedObjects();
    if (!canvas || !objects.length) {
      setStatus("Select one or more objects first.");
      return;
    }
    try {
      // Work on the individual selected objects, not the temporary ActiveSelection.
      const ordered = direction === "front" ? [...objects] : [...objects].reverse();
      ordered.forEach((object) => {
        if (direction === "front") canvas.bringObjectToFront(object);
        else canvas.sendObjectToBack(object);
      });
      canvas.requestRenderAll();
      saveHistory();
      setStatus(direction === "front" ? "Selected object(s) brought to front." : "Selected object(s) sent to back.");
    } catch (error) {
      console.error(error);
      setStatus("Could not change object layer order in this Fabric.js version.");
    }
  }

  function nudgeSelectedObjects(dx, dy) {
    const canvas = canvasRef.current;
    const active = canvas?.getActiveObject();
    if (!canvas || !active) return false;
    // Move the active object/ActiveSelection as a unit so multi-select children
    // keep their relative positions and group transforms remain intact.
    active.set({ left: (active.left || 0) + dx, top: (active.top || 0) + dy });
    active.setCoords();
    canvas.requestRenderAll();
    saveHistory();
    setStatus(`Moved selection ${dx || 0} world units horizontally and ${dy || 0} vertically.`);
    return true;
  }

  async function restoreSnapshot(snapshot) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    historyRef.current.restoring = true;
    try {
      await canvas.loadFromJSON(JSON.parse(snapshot));
      canvas.requestRenderAll();
    } finally {
      historyRef.current.restoring = false;
      syncHistoryButtons();
    }
  }

  async function undo() {
    const hist = historyRef.current;
    if (hist.undo.length <= 1) return;
    hist.redo.push(hist.undo.pop());
    await restoreSnapshot(hist.undo[hist.undo.length - 1]);
    setStatus("Undo complete.");
  }

  async function redo() {
    const hist = historyRef.current;
    if (!hist.redo.length) return;
    const snapshot = hist.redo.pop();
    hist.undo.push(snapshot);
    await restoreSnapshot(snapshot);
    setStatus("Redo complete.");
  }

  function zoomBy(factor) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const zoom = clampZoom(getZoomLevel(canvas) * factor);
    canvas.zoomToPoint(new Point(canvas.getWidth() / 2, canvas.getHeight() / 2), zoom);
    setZoomPercent(Math.round(getZoomLevel(canvas) * 100));
    canvas.requestRenderAll();
  }

  function resetView() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.setViewportTransform([1, 0, 0, 1, 0, 0]);
    setZoomPercent(100);
    canvas.requestRenderAll();
  }

  function clearCanvas() {
    const canvas = canvasRef.current;
    if (!canvas || !window.confirm("Clear all canvas objects?")) return;
    canvas.clear();
    canvas.backgroundColor = "rgba(0, 0, 0, 0)";
    canvas.requestRenderAll();
    saveHistory();
    setStatus("Canvas cleared.");
  }

  useEffect(() => {
    const onKeyDown = (event) => {
      const canvas = canvasRef.current;
      const active = canvas?.getActiveObject();
      if (!canvas || active?.isEditing || ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName)) return;
      if (event.code === "Space" && canvas.upperCanvasEl?.matches(":hover")) {
        event.preventDefault();
        spaceDownRef.current = true;
        canvas.defaultCursor = "grab";
        canvas.selection = false;
        return;
      }
      if ((event.key === "Delete" || event.key === "Backspace") && active) {
        event.preventDefault(); deleteSelectedObject();
      } else if (active && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
        // Shift + arrow moves by 10 world units; arrow alone moves by 1.
        const step = event.shiftKey ? 10 : 1;
        const delta = {
          ArrowUp: [0, -step], ArrowDown: [0, step],
          ArrowLeft: [-step, 0], ArrowRight: [step, 0],
        }[event.key];
        event.preventDefault();
        nudgeSelectedObjects(delta[0], delta[1]);
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "d") {
        event.preventDefault(); duplicateSelectedObject();
      } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z" && !event.shiftKey) {
        event.preventDefault(); undo();
      } else if ((event.ctrlKey || event.metaKey) && (event.key.toLowerCase() === "y" || (event.key.toLowerCase() === "z" && event.shiftKey))) {
        event.preventDefault(); redo();
      }
    };
    const onKeyUp = (event) => {
      if (event.code !== "Space") return;
      spaceDownRef.current = false;
      panRef.current.active = false;
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.selection = modeRef.current === "select" || modeRef.current === "text";
      canvas.defaultCursor = modeRef.current === "hand" ? "grab" : modeRef.current === "text" ? "text" : modeRef.current === "draw" || modeRef.current === "highlighter" ? "crosshair" : modeRef.current === "eraser" ? "cell" : "default";
    };
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
  });

  useEffect(() => { gridVisibleRef.current = gridVisible; snapEnabledRef.current = snapEnabled; minimapVisibleRef.current = minimapVisible; canvasRef.current?.requestRenderAll(); }, [gridVisible, snapEnabled, minimapVisible]);

  const brushNames = {
    pen: "Pen", marker: "Marker brush", highlighter: "Freehand highlighter",
    pencil: "Pencil", calligraphy: "Calligraphy",
  };

  return (
    <main className="app">
      <header className="app-header">
        <div>
          <p className="eyebrow">PIXELFORGE · THE SHARED SANCTUM</p>
          <h1>Canvas Engine + Brush Studio</h1>
          <p className="subtitle">Image-backed sticky notes, editable text, custom brushes, and highlighting.</p>
        </div>
        <span className="header-pill">React + Fabric.js</span>
      </header>

      <section className="editor-toolbar">
        <div className="toolbar-section">
          <span className="toolbar-label">Tools</span>
          <div className="toolbar-row">
            <button className={mode === "select" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("select")}>↖ Select</button>
            <button className={mode === "hand" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("hand")}>✋ Hand / Pan</button>
            <button className={mode === "text" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("text")}>T Text</button>
            <button className={mode === "draw" ? "tool-button active" : "tool-button"} onClick={() => { setBrushKind(brushKind === "highlighter" ? "pen" : brushKind); setModeAndRef("draw"); }}>✎ Draw</button>
            <button className={mode === "highlighter" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("highlighter")}>▰ Highlighter</button>
            <button className={mode === "eraser" ? "tool-button active" : "tool-button"} onClick={() => setModeAndRef("eraser")}>⌫ Eraser</button>
          </div>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Brush Studio</span>
          <div className="toolbar-row">
            <select aria-label="Brush type" value={brushKind} onChange={(e) => setBrushKind(e.target.value)}>
              <option value="pen">Pen</option>
              <option value="marker">Marker brush</option>
              <option value="pencil">Pencil (rough)</option>
              <option value="calligraphy">Calligraphy</option>
            </select>
            <label className="color-control">Ink <input type="color" value={brushColor} onChange={(e) => setBrushColor(e.target.value)} /></label>
            <label className="range-control">Size {brushWidth}px <input type="range" min="1" max="36" value={brushWidth} onChange={(e) => setBrushWidth(Number(e.target.value))} /></label>
            <label className="range-control">Opacity {Math.round(brushOpacity * 100)}% <input type="range" min="10" max="100" value={Math.round(brushOpacity * 100)} onChange={(e) => setBrushOpacity(Number(e.target.value) / 100)} /></label>
            <label className="check-control"><input type="checkbox" checked={pressureEnabled} onChange={(e) => setPressureEnabled(e.target.checked)} /> Stylus pressure</label>
          </div>
          <div className="toolbar-row">
            <label className="color-control">Highlighter color <input type="color" value={highlighterColor} onChange={(e) => setHighlighterColor(e.target.value)} /></label>
            <label className="range-control">Eraser size {eraserWidth}px <input type="range" min="8" max="60" value={eraserWidth} onChange={(e) => setEraserWidth(Number(e.target.value))} /></label>
            <select aria-label="Eraser mode" value={eraserMode} onChange={(e) => setEraserMode(e.target.value)}>
              <option value="sweep">Sweep eraser</option>
              <option value="whole">Whole-stroke eraser</option>
            </select>
            <button className="tool-button" onClick={highlightSelectedCharacters} title="Select characters while editing text first">Text highlight selection</button>
            <button className="tool-button" onClick={highlightWholeTextObject}>Highlight whole text</button>
          </div>
        </div>

        <div className="toolbar-section">
          <span className="toolbar-label">Text formatting</span>
          <div className="toolbar-row">
            <select aria-label="Font family" value={fontFamily} onChange={(e) => { setFontFamily(e.target.value); applyTextStyle({ fontFamily: e.target.value }); }}>
              {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
            <select aria-label="Font size" value={fontSize} onChange={(e) => { setFontSize(Number(e.target.value)); applyTextStyle({ fontSize: Number(e.target.value) }); }}>
              {[12,14,16,18,20,24,28,32,36,42,48,60].map((s) => <option key={s} value={s}>{s}px</option>)}
            </select>
            <button className={bold ? "format-button active" : "format-button"} onClick={() => { const v = !bold; setBold(v); applyTextStyle({ fontWeight: v ? "bold" : "normal" }); }}><b>B</b></button>
            <button className={italic ? "format-button active" : "format-button"} onClick={() => { const v = !italic; setItalic(v); applyTextStyle({ fontStyle: v ? "italic" : "normal" }); }}><i>I</i></button>
            <button className={underline ? "format-button active" : "format-button"} onClick={() => { const v = !underline; setUnderline(v); applyTextStyle({ underline: v }); }}><u>U</u></button>
            <select aria-label="Text alignment" value={textAlign} onChange={(e) => { setTextAlign(e.target.value); applyTextStyle({ textAlign: e.target.value }); }}>
              <option value="left">Left</option><option value="center">Center</option><option value="right">Right</option><option value="justify">Justify</option>
            </select>
            <label className="color-control">Text <input type="color" value={textColor} onChange={(e) => { setTextColor(e.target.value); applyTextStyle({ fill: e.target.value }); }} /></label>
            <label className="color-control">Text BG <input type="color" value={textBackground === "transparent" ? "#FFF4B8" : textBackground} onChange={(e) => { setTextBackground(e.target.value); applyTextStyle({ backgroundColor: e.target.value }); }} /></label>
            <button className="format-button" onClick={() => { setTextBackground("transparent"); applyTextStyle({ backgroundColor: "" }); }}>Clear BG</button>
            <label className="line-control">Line spacing
              <select value={lineSpacing} onChange={(e) => { setLineSpacing(Number(e.target.value)); applyTextStyle({ lineHeight: Number(e.target.value) }); }}>
                {[0.9,1,1.2,1.5,1.8,2].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </label>
          </div>
        </div>

      </section>

      <div className="workspace">
        <aside className="designer">
          <section className="panel-section">
            <h2>Sticky-note templates</h2>
            <div className="template-grid">
              {Object.entries(STICKY_TEMPLATES).map(([id, style]) => (
                <button key={id} className={`template-option ${template === id ? "selected" : ""}`} onClick={() => setTemplate(id)} type="button">
                  <img className="template-swatch-image" src={style.image} alt="" draggable="false" />
                  <span className="template-option-name">{style.name}</span>
                </button>
              ))}
            </div>
          </section>
          <section className="panel-section">
            <h2>Sticky-note header</h2>
            <label>Heading text<input value={header} onChange={(e) => setHeader(e.target.value)} /></label>
            <label>Heading font<select value={headerFont} onChange={(e) => setHeaderFont(e.target.value)}>{FONTS.map((f) => <option key={f}>{f}</option>)}</select></label>
            <label>Heading size: {headerSize}px<input type="range" min="14" max="36" value={headerSize} onChange={(e) => setHeaderSize(Number(e.target.value))} /></label>
            <div className="color-row"><label>Heading color</label><input type="color" value={headerColor || selectedTemplate.foreground} onChange={(e) => setHeaderColor(e.target.value)} /></div>
          </section>
          <section className="panel-section">
            <h2>Sticky-note body</h2>
            <label>Body text<textarea value={body} onChange={(e) => setBody(e.target.value)} rows={3} /></label>
            <label>Body font<select value={bodyFont} onChange={(e) => setBodyFont(e.target.value)}>{FONTS.map((f) => <option key={f}>{f}</option>)}</select></label>
            <label>Body size: {bodySize}px<input type="range" min="10" max="28" value={bodySize} onChange={(e) => setBodySize(Number(e.target.value))} /></label>
            <div className="color-row"><label>Body color</label><input type="color" value={bodyColor || selectedTemplate.foreground} onChange={(e) => setBodyColor(e.target.value)} /></div>
          </section>
          <section className="panel-section">
            <h2>Note dimensions</h2>
            <label>Width: {noteWidth}px<input type="range" min="220" max="360" step="10" value={noteWidth} onChange={(e) => setNoteWidth(Number(e.target.value))} /></label>
            <label>Height: {noteHeight}px<input type="range" min="160" max="300" step="10" value={noteHeight} onChange={(e) => setNoteHeight(Number(e.target.value))} /></label>
            <div className="preview-stage">
              <div className="note-preview" style={{ width: `${Math.min(noteWidth,300)}px`, height: `${Math.min(noteHeight,240)}px`, backgroundImage: `url("${selectedTemplate.image}")` }}>
                <div className="preview-header" style={{ fontFamily: headerFont, fontSize: `${headerSize}px`, color: headerColor || selectedTemplate.foreground }}>{header || "Title"}</div>
                <div className="preview-body" style={{ fontFamily: bodyFont, fontSize: `${bodySize}px`, color: bodyColor || selectedTemplate.foreground }}>{body || "Write something..."}</div>
              </div>
            </div>
            <button className="primary-button" onClick={addDesignedStickyNote} disabled={busy}>{busy ? "Loading image..." : "+ Add Sticky Note"}</button>
            <button className="secondary-button" onClick={clearCanvas}>Clear Canvas</button>
          </section>
          <p className="status-message" role="status">{status}</p>
        </aside>

        <section className="canvas-panel">
          <div className="canvas-heading">
            <div>
              <h2>Your canvas</h2>
              <p>{mode === "hand" ? "Drag to move around the canvas. You can also hold Space and drag." : mode === "text" ? "Click an empty spot to create text." : mode === "draw" ? `Draw with ${brushNames[brushKind] || "your brush"}.` : mode === "highlighter" ? "Draw translucent strokes over any canvas content." : mode === "eraser" ? (eraserMode === "sweep" ? "Sweep over strokes to erase them." : "Click a stroke to remove the whole stroke.") : "Select, move, resize, rotate and layer objects. Arrow keys nudge the selection; Shift + arrows move 10 world units. Double-click standalone text to edit."}</p>
            </div>
            <div className="canvas-nav-controls">
              <button className="tool-button" onClick={() => zoomBy(1.2)} aria-label="Zoom in">＋</button>
              <span className="zoom-readout">{zoomPercent}%</span>
              <button className="tool-button" onClick={() => zoomBy(1 / 1.2)} aria-label="Zoom out">−</button>
              <button className="tool-button" onClick={resetView}>Reset view</button>
              <button className={gridVisible ? "tool-button active" : "tool-button"} onClick={() => setGridVisible((v) => !v)}>Grid {gridVisible ? "On" : "Off"}</button>
              <button className={snapEnabled ? "tool-button active" : "tool-button"} onClick={() => setSnapEnabled((v) => !v)}>Snap {snapEnabled ? "On" : "Off"}</button>
              <button className={minimapVisible ? "tool-button active" : "tool-button"} onClick={() => setMinimapVisible((v) => !v)}>Minimap {minimapVisible ? "On" : "Off"}</button>
              <span className="canvas-tag">{selectedObject ? (selectedObject.isPixelForgeText ? "Text selected" : selectedObject.isPixelForgeStroke ? "Stroke selected" : "Object selected") : "No selection"}</span>
            </div>
          </div>
          <div className="canvas-frame"><canvas ref={canvasElement} />
            {selectedObject && floatingToolbarPosition && mode === "select" && !selectedObject.isEditing && <div className="floating-object-toolbar" style={{ left: floatingToolbarPosition.left, top: floatingToolbarPosition.top }} onMouseDown={(event) => event.stopPropagation()}>
              <button className="tool-button" onClick={undo} disabled={!canUndo} title="Undo">↶ Undo</button>
              <button className="tool-button" onClick={redo} disabled={!canRedo} title="Redo">↷ Redo</button>
              <button className="tool-button" onClick={duplicateSelectedObject}>Duplicate</button>
              <button className="tool-button" onClick={() => moveSelectedLayer("front")}>Bring to front</button>
              <button className="tool-button" onClick={() => moveSelectedLayer("back")}>Send to back</button>
              <button className="tool-button danger" onClick={deleteSelectedObject}>Delete</button>
            </div>}
            {minimapVisible && <div className="minimap-wrap"><span>MINIMAP</span><canvas ref={minimapElement} width="190" height="130" onClick={navigateFromMinimap} aria-label="Canvas minimap; click to navigate" /></div>}
          </div>
          <p className="hint">Select multiple objects with Shift-click or drag a selection box. Drag handles to resize or rotate. Arrow keys nudge selected objects (Shift + arrow = 10 world units). Ctrl/Cmd + D duplicates; Delete removes. Use Bring to front / Send to back to change layer order. Text formatting applies to standalone canvas text; sticky-note header/body formatting remains in the designer.</p>
        </section>
      </div>
    </main>
  );
}
